import { GoogleGenAI } from "@google/genai";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// API health endpoint
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

// Gemini AI Assistant endpoint
app.post("/api/ai/advise", async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: "GEMINI_API_KEY environment variable is not set." });
    }
    const ai = new GoogleGenAI({ apiKey });
    const { prompt, context } = req.body;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          role: "user",
          parts: [
            {
              text: `You are an expert outdoor wilderness trip advisor, veteran park ranger, and safety manager.
You are helping plan a camping and hiking expedition.
Trip context: ${JSON.stringify(context || {})}

User request: ${prompt}

Provide direct, actionable, highly practical advice (gear, weather precautions, meal planning, safety triggers, or Leave No Trace principles). Format with concise markdown headers and bullet points.`
            }
          ]
        }
      ]
    });

    res.json({ reply: response.text });
  } catch (err: any) {
    console.error("AI advise error:", err);
    res.status(500).json({ error: err?.message || "Failed to generate AI advice." });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
