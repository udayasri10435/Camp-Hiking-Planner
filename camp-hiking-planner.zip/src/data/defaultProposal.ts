import { ExpeditionPlan } from '../types';

export const defaultProposal: ExpeditionPlan = {
  id: 'expedition-default-2026',
  title: 'Camp Hiking Planner',
  preparedFor: 'Wilderness Explorers Group',
  preparedBy: 'Expedition Planning Team',
  date: '2026-08-15',
  tripDuration: '3 Days / 2 Nights',
  locationName: 'Pine Ridge & Mirror Lake Trailhead',
  executiveSummary:
    'This proposal outlines a comprehensive plan for a weekend camp hiking expedition designed to balance adventure, safety, and logistical efficiency. The plan is built around a structured itinerary, essential gear, risk management, and environmental stewardship. The goal is to create a memorable outdoor experience that is safe, well-organized, and adaptable to changing conditions, drawing on proven planning frameworks and best practices for multi-day treks.',
  
  // Section 2: Objectives
  primaryObjective: 'Team-building retreat & backcountry navigation skills practice',
  groupSize: '6 participants',
  groupProfile: 'Mixed experience levels (2 experienced leads, 4 intermediate hikers)',
  tripType: 'Basecamp with alpine day hikes & summit push',
  keyThemes: [
    'Wildlife observation',
    'Outdoor photography',
    'Navigation skills practice',
    'Stargazing',
    'Leave No Trace'
  ],

  // Section 3: Location Strategy
  terrainVariety: 'Moderate alpine elevation gain (1,400 ft total), mixed pine forest and granite ridge trails with natural water access.',
  waterAccess: 'Multiple clear alpine stream crossings on Days 1 and 2; Mirror Lake source at campsite.',
  permitRequirements: 'Backcountry wilderness camping permit and campfire permit required by Park Service.',
  seasonalWeather: 'Expected highs around 72°F (22°C), night lows down to 44°F (7°C). Low chance of precipitation (15%).',
  permitsSecured: true,
  permitDocLink: 'https://example.com/permits/wildlife-2026-pass.pdf',

  // Section 4: Itinerary
  itinerary: [
    {
      id: 'day-1',
      dayNumber: 1,
      title: 'Arrival & Basecamp Setup',
      subtitle: 'Trailhead departure, gear verification, and camp orientation',
      scheduleItems: [
        {
          id: 'd1-1',
          timeOfDay: '08:00 AM',
          activity: 'Departure & Travel',
          details: 'Meet at central hub, complete gear cross-check, and drive to Pine Ridge Trailhead.',
          location: 'Central Meeting Hub',
          completed: false
        },
        {
          id: 'd1-2',
          timeOfDay: '11:30 AM',
          activity: 'Trailhead Arrival & Safety Briefing',
          details: 'Final pack weight check, sign trailhead register, and issue safety briefing.',
          location: 'Pine Ridge Trailhead',
          completed: false
        },
        {
          id: 'd1-3',
          timeOfDay: '01:30 PM',
          activity: 'Hike to Basecamp (3.5 miles)',
          details: 'Steady incline along Mirror Creek; practice pacing and hydration stops.',
          location: 'Mirror Creek Trail',
          completed: false
        },
        {
          id: 'd1-4',
          timeOfDay: '04:00 PM',
          activity: 'Camp Setup & Water Filtration',
          details: 'Pitch group tents 200ft from water source; establish bear-proof food storage tree.',
          location: 'Mirror Lake Campsite #4',
          completed: false
        },
        {
          id: 'd1-5',
          timeOfDay: '06:30 PM',
          activity: 'Campfire Dinner & Stargazing',
          details: 'Prepare group dehydrated meals; review Day 2 route map under night sky.',
          location: 'Mirror Lake Basecamp',
          completed: false
        }
      ]
    },
    {
      id: 'day-2',
      dayNumber: 2,
      title: 'Main Exploration & Ridge Hike',
      subtitle: 'Summit push to Scenic Overlook & skill-building workshops',
      scheduleItems: [
        {
          id: 'd2-1',
          timeOfDay: '06:30 AM',
          activity: 'Wake-Up & Hearty Breakfast',
          details: 'Oatmeal, hot coffee/tea, pack daypacks with 3 quarts water and high-energy snacks.',
          location: 'Basecamp Kitchen',
          completed: false
        },
        {
          id: 'd2-2',
          timeOfDay: '08:00 AM',
          activity: 'Ridge Trail Hike (6.2 miles round-trip)',
          details: 'Ascend switchbacks to Ridge View Point; practice map and compass navigation.',
          location: 'Eagle Ridge Pass',
          completed: false
        },
        {
          id: 'd2-3',
          timeOfDay: '12:00 PM',
          activity: 'Summit Overlook Lunch & Photography',
          details: 'Panoramic views, rest, wildlife observation from distance, and group photo.',
          location: 'Eagle Ridge Overlook (Alt. 6,800 ft)',
          completed: false
        },
        {
          id: 'd2-4',
          timeOfDay: '03:30 PM',
          activity: 'Return to Camp & Knot Tying Workshop',
          details: 'Descend to basecamp; rest break followed by backcountry knot tying and tarp rigging practice.',
          location: 'Mirror Lake Basecamp',
          completed: false
        },
        {
          id: 'd2-5',
          timeOfDay: '07:00 PM',
          activity: 'Group Reflection & Campfire Storytelling',
          details: 'Cook one-pot pasta; share trip highlights and conduct evening weather check.',
          location: 'Basecamp Circle',
          completed: false
        }
      ]
    },
    {
      id: 'day-3',
      dayNumber: 3,
      title: 'Wrap-Up & Departure',
      subtitle: 'Camp breakdown, Leave No Trace cleanup, and debrief',
      scheduleItems: [
        {
          id: 'd3-1',
          timeOfDay: '07:00 AM',
          activity: 'Breakfast & Break Camp',
          details: 'Dry out rainflies, pack sleeping bags, assemble personal gear.',
          location: 'Basecamp',
          completed: false
        },
        {
          id: 'd3-2',
          timeOfDay: '09:00 AM',
          activity: 'Leave No Trace Site Sweep',
          details: 'Conduct grid-pattern campsite inspection to ensure zero waste or micro-trash remains.',
          location: 'Mirror Lake Campsite #4',
          completed: false
        },
        {
          id: 'd3-3',
          timeOfDay: '10:00 AM',
          activity: 'Return Hike to Trailhead (3.5 miles)',
          details: 'Gentle downhill hike, enjoying morning light and mountain views.',
          location: 'Mirror Creek Trail',
          completed: false
        },
        {
          id: 'd3-4',
          timeOfDay: '01:00 PM',
          activity: 'Trailhead Debrief & Home Departure',
          details: 'Sign out at ranger station, group debrief over casual lunch, drive back.',
          location: 'Pine Ridge Ranger Station',
          completed: false
        }
      ]
    }
  ],

  // Section 5: Gear
  gearItems: [
    // Group Equipment
    { id: 'g1', name: '4-Person Backpacking Tents (2x)', quantity: 2, weightLbs: 9.5, assignedTo: 'Lead Hiker Alex', packed: true, isEssential: true, category: 'Shelter', type: 'group' },
    { id: 'g2', name: 'Lightweight Camp Tarp & Groundsheet', quantity: 1, weightLbs: 2.1, assignedTo: 'Sam', packed: true, isEssential: true, category: 'Shelter', type: 'group' },
    { id: 'g3', name: 'Compact Isobutane Stoves & Fuel Canisters', quantity: 2, weightLbs: 2.8, assignedTo: 'Jordan', packed: true, isEssential: true, category: 'Kitchen', type: 'group' },
    { id: 'g4', name: 'Squeeze Water Filter & Purification Tablets', quantity: 2, weightLbs: 1.2, assignedTo: 'Taylor', packed: true, isEssential: true, category: 'Kitchen', type: 'group' },
    { id: 'g5', name: 'Anodized Aluminum Cookset & Utensils', quantity: 1, weightLbs: 1.8, assignedTo: 'Jordan', packed: false, isEssential: true, category: 'Kitchen', type: 'group' },
    { id: 'g6', name: 'Wilderness First Aid Kit & SAM Splint', quantity: 1, weightLbs: 2.5, assignedTo: 'Lead Hiker Alex', packed: true, isEssential: true, category: 'Safety', type: 'group' },
    { id: 'g7', name: 'Bear-Proof Vault / Food Hang Rope (100ft)', quantity: 1, weightLbs: 2.2, assignedTo: 'Chris', packed: true, isEssential: true, category: 'Safety', type: 'group' },
    { id: 'g8', name: 'Topographic Map & Magnetic Compass', quantity: 2, weightLbs: 0.5, assignedTo: 'Lead Hiker Alex', packed: true, isEssential: true, category: 'Tools', type: 'group' },
    { id: 'g9', name: 'Multi-tool & Gear Repair Kit (Duct Tape, Cordage)', quantity: 1, weightLbs: 1.1, assignedTo: 'Sam', packed: false, isEssential: false, category: 'Tools', type: 'group' },
    
    // Personal Equipment
    { id: 'p1', name: '50-65L Adjustable Internal Frame Backpack', quantity: 1, weightLbs: 4.2, assignedTo: 'Self', packed: true, isEssential: true, category: 'Backpack', type: 'personal' },
    { id: 'p2', name: '3-Season Sleeping Bag (Rated 20°F)', quantity: 1, weightLbs: 2.8, assignedTo: 'Self', packed: true, isEssential: true, category: 'Sleep System', type: 'personal' },
    { id: 'p3', name: 'Insulated Inflatable Sleeping Pad (R-Value 4.0)', quantity: 1, weightLbs: 1.3, assignedTo: 'Self', packed: true, isEssential: true, category: 'Sleep System', type: 'personal' },
    { id: 'p4', name: 'Moisture-Wicking Synthetic Base Layers (2x)', quantity: 2, weightLbs: 1.0, assignedTo: 'Self', packed: true, isEssential: true, category: 'Clothing', type: 'personal' },
    { id: 'p5', name: 'Fleece Mid-Layer / Puffy Down Jacket', quantity: 1, weightLbs: 1.1, assignedTo: 'Self', packed: true, isEssential: true, category: 'Clothing', type: 'personal' },
    { id: 'p6', name: 'Waterproof Gore-Tex Shell Jacket & Pants', quantity: 1, weightLbs: 1.4, assignedTo: 'Self', packed: true, isEssential: true, category: 'Clothing', type: 'personal' },
    { id: 'p7', name: '300-Lumen Headlamp + Extra Lithium Batteries', quantity: 1, weightLbs: 0.4, assignedTo: 'Self', packed: true, isEssential: true, category: 'Navigation', type: 'personal' },
    { id: 'p8', name: 'Hydration Reservoir (2L) + 1L Nalgene Water Bottle', quantity: 1, weightLbs: 0.8, assignedTo: 'Self', packed: true, isEssential: true, category: 'Hydration', type: 'personal' }
  ],

  // Section 6: Safety
  checkInPersonName: 'Sarah Jenkins (Home Emergency Contact)',
  checkInPersonPhone: '+1 (555) 382-9102',
  satelliteDevice: 'Garmin InReach Mini 2 (Device ID: #8492-INREACH)',
  wildlifeProtocol: 'Bear canisters placed 100ft downwind from tents; food hang elevated 12ft high and 6ft away from trunk. No food or scented items inside tents.',
  decisionTrigger: 'If sustained winds exceed 35mph, thunderstorm warnings are issued, or daylight drops under 90 minutes before reaching milestone, halt ascent and retreat to lower tree-line shelter.',
  emergencyContacts: [
    { id: 'ec1', name: 'Pine Ridge Ranger Station', role: 'District Park Ranger', phone: '+1 (555) 928-1000', notes: 'Monitored 8am-5pm daily; VHF Radio Ch 16' },
    { id: 'ec2', name: 'County Search & Rescue', role: 'Emergency Dispatch', phone: '911 / +1 (555) 911-0022', notes: 'Direct satellite emergency dispatch' },
    { id: 'ec3', name: 'Regional Hospital Emergency Room', role: 'Medical Center', phone: '+1 (555) 441-2900', notes: 'Nearest trauma facility, 42 miles from trailhead' }
  ],

  // Section 7: Nutrition & Water
  dailyCaloriesTarget: 3200,
  waterCapacityQuarts: 3,
  waterTreatmentMethod: 'Sawyer Squeeze Gravity Filter + AquaMira Chlorine Dioxide Drops backup (boil minimum 1 min).',
  mealPlan: [
    {
      id: 'm1',
      dayNumber: 1,
      breakfast: 'At home prior to departure / Granola bar at trailhead',
      lunch: 'Trail turkey & cheese wraps, almond butter packs, dried cranberries',
      dinner: 'Dehydrated Beef Stroganoff / Chili Mac, hot cocoa, dark chocolate bar',
      snacks: 'Trail mix (nuts, M&Ms, raisins), beef jerky, electrolyte chews'
    },
    {
      id: 'm2',
      dayNumber: 2,
      breakfast: 'Instant oatmeal with chia seeds & dried apples, instant roast coffee/tea',
      lunch: 'Pita pockets with tuna pouch, hummus spread, crushed pretzels',
      dinner: 'One-pot pesto pasta with sun-dried tomatoes & chicken breast, peppermint tea',
      snacks: 'Energy bars, dried mango, salted cashews, hydration tablets'
    },
    {
      id: 'm3',
      dayNumber: 3,
      breakfast: 'Freeze-dried eggs & hashbrowns, hot tea',
      lunch: 'Peanut butter & honey tortillas, remaining trail mix',
      dinner: 'Celebratory group lunch at mountain tavern post-trailhead departure',
      snacks: 'Protein bars, gummy chews'
    }
  ],

  // Section 8: Budget
  budgetItems: [
    { id: 'b1', category: 'Permits & Park Entry Fees', estimatedCost: 75.0, actualCost: 75.0, notes: 'Wilderness pass ($50) + Campfire permit ($25)' },
    { id: 'b2', category: 'Transportation & Fuel', estimatedCost: 120.0, actualCost: 110.0, notes: 'Carpool fuel for 2 vehicles (240 miles total)' },
    { id: 'b3', category: 'Group Meals & Freeze-Dried Rations', estimatedCost: 210.0, actualCost: 195.0, notes: 'Dehydrated meals, coffee, group snacks for 6' },
    { id: 'b4', category: 'Gear Rental & Supplies', estimatedCost: 80.0, actualCost: 65.0, notes: 'Bear canister rental ($30) + fuel canisters ($35)' },
    { id: 'b5', category: 'Contingency Emergency Reserve', estimatedCost: 100.0, actualCost: 0.0, notes: 'Set aside for unexpected weather shelter or road detour' }
  ],
  fundraisingNotes: 'Participant dues ($85 per person) cover all shared expenses and gear rentals.',

  // Section 9: LNT
  lntRules: [
    { id: 'l1', number: 1, title: 'Plan Ahead and Prepare', description: 'Know regulations, prepare for extreme weather, hazards, and emergencies.', checked: true, actionItem: 'Permits secured; route maps printed on waterproof paper.' },
    { id: 'l2', number: 2, title: 'Travel and Camp on Durable Surfaces', description: 'Established trails and campsites, rock, gravel, dry grasses, or snow.', checked: true, actionItem: 'Campsite #4 at Mirror Lake is pre-designated durable ground.' },
    { id: 'l3', number: 3, title: 'Dispose of Waste Properly', description: 'Pack it in, pack it out. Inspect campsite for trash and spilled foods.', checked: true, actionItem: 'Bring dedicated trash contractor bags; dig catholes 6-8 in deep.' },
    { id: 'l4', number: 4, title: 'Leave What You Find', description: 'Preserve the past: examine, but do not touch cultural or natural objects.', checked: true, actionItem: 'Take photos only; leave rocks, wildflowers, and pinecones.' },
    { id: 'l5', number: 5, title: 'Minimize Campfire Impacts', description: 'Use a lightweight stove for cooking. Where fires are permitted, use mound fires.', checked: true, actionItem: 'Rely on gas stoves for cooking; burn only small dead wood in existing ring.' },
    { id: 'l6', number: 6, title: 'Respect Wildlife', description: 'Observe wildlife from a distance. Never feed animals or leave food unattended.', checked: true, actionItem: 'Use bear vault; keep 100 yards from megafauna.' },
    { id: 'l7', number: 7, title: 'Be Considerate of Other Visitors', description: 'Respect other visitors and protect the quality of their experience.', checked: true, actionItem: 'Maintain quiet hours after 9:00 PM; yield to uphill hikers.' }
  ],

  // Section 10: Post-Trip
  equipmentCheckComplete: false,
  siteInspectionDone: true,
  debriefNotes: 'Schedule 20-minute group video debrief 48 hours post-trip to gather gear performance feedback.',
  photoAlbumUrl: 'https://photos.app.goo.gl/camp-hiking-2026-album',

  updatedAt: Date.now()
};
