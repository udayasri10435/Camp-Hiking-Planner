import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  onSnapshot,
  collection,
  query,
  where,
  getDocs,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { ExpeditionPlan } from '../types';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');
export const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error: any) {
    console.error("Google Sign-In failed:", error);
    throw error;
  }
};

export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Sign-Out failed:", error);
  }
};

// Firestore helper functions
export const saveExpeditionPlan = async (plan: ExpeditionPlan, userId?: string) => {
  try {
    const planRef = doc(db, 'expeditions', plan.id);
    const dataToSave = {
      ...plan,
      userId: userId || plan.userId || 'guest',
      updatedAt: Date.now(),
    };
    await setDoc(planRef, dataToSave, { merge: true });
    return true;
  } catch (error) {
    console.error("Error saving expedition plan to Firestore:", error);
    return false;
  }
};

export const loadExpeditionPlan = async (planId: string): Promise<ExpeditionPlan | null> => {
  try {
    const planRef = doc(db, 'expeditions', planId);
    const snap = await getDoc(planRef);
    if (snap.exists()) {
      return snap.data() as ExpeditionPlan;
    }
    return null;
  } catch (error) {
    console.error("Error loading expedition plan:", error);
    return null;
  }
};

export const subscribeToPlan = (
  planId: string,
  callback: (plan: ExpeditionPlan | null) => void
) => {
  const planRef = doc(db, 'expeditions', planId);
  return onSnapshot(
    planRef,
    (docSnap) => {
      if (docSnap.exists()) {
        callback(docSnap.data() as ExpeditionPlan);
      } else {
        callback(null);
      }
    },
    (error) => {
      console.error("Firestore plan subscription error:", error);
      callback(null);
    }
  );
};

export const getUserPlans = async (userId: string): Promise<ExpeditionPlan[]> => {
  try {
    const q = query(collection(db, 'expeditions'), where('userId', '==', userId));
    const querySnapshot = await getDocs(q);
    const plans: ExpeditionPlan[] = [];
    querySnapshot.forEach((docSnap) => {
      plans.push(docSnap.data() as ExpeditionPlan);
    });
    return plans;
  } catch (error) {
    console.error("Error fetching user plans:", error);
    return [];
  }
};
