import React from 'react';
import { ExpeditionPlan, LntRule } from '../types';
import {
  Leaf,
  CheckCircle2,
  Circle,
  Trees,
  Footprints,
  Trash,
  Eye,
  Flame,
  Heart,
  Volume2
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const LeaveNoTraceSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const checkedCount = plan.lntRules.filter((r) => r.checked).length;
  const progressPct = Math.round((checkedCount / plan.lntRules.length) * 100);

  const handleToggleRule = (ruleId: string) => {
    const updated = plan.lntRules.map((rule) =>
      rule.id === ruleId ? { ...rule, checked: !rule.checked } : rule
    );
    onUpdatePlan({ lntRules: updated });
  };

  const handleUpdateAction = (ruleId: string, text: string) => {
    const updated = plan.lntRules.map((rule) =>
      rule.id === ruleId ? { ...rule, actionItem: text } : rule
    );
    onUpdatePlan({ lntRules: updated });
  };

  const getPrincipleIcon = (num: number) => {
    switch (num) {
      case 1: return Footprints;
      case 2: return Trees;
      case 3: return Trash;
      case 4: return Eye;
      case 5: return Flame;
      case 6: return Heart;
      case 7: return Volume2;
      default: return Leaf;
    }
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-emerald-700 rounded-lg text-white border-2 border-emerald-950">
              <Leaf className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">9. Environmental Responsibility (Leave No Trace)</h2>
          </div>

          <div className="flex items-center space-x-2 bg-emerald-50 px-3 py-1.5 rounded-2xl border-2 border-emerald-900 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
            <span className="text-xs font-black text-emerald-900 uppercase">Pledge Compliance:</span>
            <span className="text-xs font-black text-orange-600 font-mono">
              {checkedCount}/7 Verified ({progressPct}%)
            </span>
          </div>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-6">
          Strict adherence to Leave No Trace (LNT) principles preserves the wilderness for future visitors. Confirm group execution actions below.
        </p>

        {/* 7 Principles Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plan.lntRules.map((rule) => {
            const Icon = getPrincipleIcon(rule.number);
            return (
              <div
                key={rule.id}
                className={`p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] transition ${
                  rule.checked
                    ? 'bg-emerald-100/90'
                    : 'bg-emerald-50'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2.5">
                    <div
                      className={`p-2 rounded-xl border-2 border-emerald-900 ${
                        rule.checked
                          ? 'bg-orange-500 text-white shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]'
                          : 'bg-white text-emerald-900'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono font-black text-orange-600 uppercase">
                        Principle #{rule.number}
                      </span>
                      <h3 className="text-sm font-black text-emerald-950 uppercase">{rule.title}</h3>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggleRule(rule.id)}
                    className="p-1 text-emerald-900 hover:text-orange-500 transition"
                  >
                    {rule.checked ? (
                      <CheckCircle2 className="w-6 h-6 text-orange-600 fill-orange-100" />
                    ) : (
                      <Circle className="w-6 h-6 text-emerald-800" />
                    )}
                  </button>
                </div>

                <p className="text-xs font-bold text-emerald-900 leading-relaxed mb-3">{rule.description}</p>

                <div>
                  <label className="text-[10px] text-emerald-900 font-black block mb-1 uppercase">
                    Trip Execution & Mitigation Plan
                  </label>
                  <input
                    type="text"
                    value={rule.actionItem}
                    onChange={(e) => handleUpdateAction(rule.id, e.target.value)}
                    className="w-full bg-white border-2 border-emerald-900 rounded-xl px-2.5 py-1 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
