import React, { useState } from 'react';
import { ExpeditionPlan, GearItem } from '../types';
import {
  Backpack,
  Plus,
  Trash2,
  CheckSquare,
  Square,
  Scale,
  Users,
  ShieldAlert,
  Compass,
  Sparkles,
  Filter
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const GearPackingSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const [activeType, setActiveType] = useState<'all' | 'group' | 'personal'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showAddModal, setShowAddModal] = useState(false);

  // New item state
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<'group' | 'personal'>('group');
  const [newCategory, setNewCategory] = useState('Shelter');
  const [newQuantity, setNewQuantity] = useState(1);
  const [newWeight, setNewWeight] = useState(1.0);
  const [newAssigned, setNewAssigned] = useState('Self');
  const [newIsEssential, setNewIsEssential] = useState(true);

  // Filter items
  const filteredItems = plan.gearItems.filter((item) => {
    if (activeType !== 'all' && item.type !== activeType) return false;
    if (selectedCategory !== 'All' && item.category !== selectedCategory) return false;
    return true;
  });

  // Calculate totals
  const totalWeightLbs = plan.gearItems.reduce(
    (acc, item) => acc + item.weightLbs * item.quantity,
    0
  );
  const totalWeightKg = (totalWeightLbs * 0.453592).toFixed(1);

  const packedCount = plan.gearItems.filter((i) => i.packed).length;
  const packedPercent =
    plan.gearItems.length > 0
      ? Math.round((packedCount / plan.gearItems.length) * 100)
      : 0;

  const categories = [
    'All',
    'Shelter',
    'Kitchen',
    'Safety',
    'Tools',
    'Backpack',
    'Sleep System',
    'Clothing',
    'Navigation',
    'Hydration'
  ];

  const handleTogglePacked = (itemId: string) => {
    const updatedGear = plan.gearItems.map((item) =>
      item.id === itemId ? { ...item, packed: !item.packed } : item
    );
    onUpdatePlan({ gearItems: updatedGear });
  };

  const handleDeleteItem = (itemId: string) => {
    const updatedGear = plan.gearItems.filter((item) => item.id !== itemId);
    onUpdatePlan({ gearItems: updatedGear });
  };

  const handleAddGearItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newItem: GearItem = {
      id: `gear-${Date.now()}`,
      name: newName.trim(),
      type: newType,
      category: newCategory,
      quantity: Number(newQuantity) || 1,
      weightLbs: Number(newWeight) || 0,
      assignedTo: newAssigned.trim() || 'Self',
      packed: false,
      isEssential: newIsEssential
    };

    onUpdatePlan({ gearItems: [...plan.gearItems, newItem] });
    setNewName('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Pack Summary Meter */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b-2 border-emerald-100 pb-4 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-orange-500 rounded-lg text-white border-2 border-emerald-900">
              <Backpack className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">5. Essential Gear & Packing Plan</h2>
              <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide">
                Prioritize lightweight essentials. Conduct a test pack at home to check fit and weight distribution.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-1.5 text-xs font-black uppercase bg-orange-500 hover:bg-orange-400 text-white px-3.5 py-2 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition self-start md:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Custom Item</span>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <div className="flex items-center justify-between text-xs font-black text-emerald-900 uppercase mb-1">
              <span>Packing Progress</span>
              <span className="font-mono text-orange-600 font-black">{packedPercent}%</span>
            </div>
            <div className="w-full h-3 bg-white border-2 border-emerald-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-orange-500 transition-all duration-300"
                style={{ width: `${packedPercent}%` }}
              />
            </div>
            <p className="text-[11px] font-bold text-emerald-800 uppercase tracking-wide mt-1.5">
              {packedCount} of {plan.gearItems.length} items packed
            </p>
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] flex items-center justify-between">
            <div>
              <p className="text-xs font-black text-emerald-900 uppercase">Total Load Weight</p>
              <p className="text-xl font-black text-emerald-950 font-mono">
                {totalWeightLbs.toFixed(1)} <span className="text-xs text-emerald-800 font-sans uppercase">lbs</span>
              </p>
            </div>
            <div className="text-right">
              <p className="text-xs font-black text-emerald-900 uppercase">Metric</p>
              <p className="text-sm font-black text-sky-700 font-mono">{totalWeightKg} kg</p>
            </div>
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] flex items-center justify-between">
            <div>
              <p className="text-xs font-black text-emerald-900 uppercase">Gear Type Ratio</p>
              <p className="text-xs text-emerald-950 font-black uppercase mt-1">
                Group: <span className="text-orange-600">{plan.gearItems.filter(i => i.type === 'group').length}</span> | Personal: <span className="text-sky-700">{plan.gearItems.filter(i => i.type === 'personal').length}</span>
              </p>
            </div>
            <Scale className="w-6 h-6 text-emerald-900" />
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-4 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Type Switcher */}
        <div className="flex space-x-1 bg-emerald-50 p-1 rounded-xl border-2 border-emerald-900">
          {(['all', 'group', 'personal'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setActiveType(type)}
              className={`px-3 py-1 rounded-lg text-xs font-black uppercase transition border-2 ${
                activeType === type
                  ? 'bg-orange-500 text-white border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]'
                  : 'bg-transparent text-emerald-900 border-transparent hover:bg-emerald-100'
              }`}
            >
              {type === 'all' ? 'All Gear' : `${type} Gear`}
            </button>
          ))}
        </div>

        {/* Category Selector */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <Filter className="w-4 h-4 text-emerald-900 shrink-0" />
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-xl text-xs font-black uppercase whitespace-nowrap transition border-2 ${
                selectedCategory === cat
                  ? 'bg-emerald-900 text-white border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]'
                  : 'bg-emerald-50 text-emerald-900 border-emerald-900 hover:bg-emerald-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Gear Item List Table */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl overflow-hidden shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-emerald-100 text-emerald-950 border-b-2 border-emerald-900 font-black text-xs uppercase tracking-wider">
                <th className="py-3 px-4 w-10 text-center">Status</th>
                <th className="py-3 px-4">Item Name</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Type</th>
                <th className="py-3 px-4 text-center">Qty</th>
                <th className="py-3 px-4 text-right">Weight (lbs)</th>
                <th className="py-3 px-4">Assigned To</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-emerald-100 text-emerald-950 font-bold">
              {filteredItems.map((item) => (
                <tr
                  key={item.id}
                  className={`hover:bg-emerald-50 transition ${
                    item.packed ? 'bg-emerald-50/50 text-emerald-700' : ''
                  }`}
                >
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleTogglePacked(item.id)}
                      className="text-emerald-900 hover:text-orange-500 transition"
                    >
                      {item.packed ? (
                        <CheckSquare className="w-5 h-5 text-emerald-900" />
                      ) : (
                        <Square className="w-5 h-5 text-emerald-700" />
                      )}
                    </button>
                  </td>

                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <span className={item.packed ? 'line-through text-emerald-700' : 'text-emerald-950 font-black'}>
                        {item.name}
                      </span>
                      {item.isEssential && (
                        <span className="text-[10px] bg-rose-500 text-white border border-rose-800 px-1.5 py-0.2 rounded font-black uppercase">
                          Essential
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="py-3 px-4 text-xs font-bold text-emerald-800 uppercase">{item.category}</td>

                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] uppercase font-black font-mono px-2 py-0.5 rounded border-2 border-emerald-950 shadow-[1px_1px_0px_0px_rgba(6,78,59,1)] ${
                        item.type === 'group'
                          ? 'bg-orange-500 text-white'
                          : 'bg-sky-500 text-white'
                      }`}
                    >
                      {item.type}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-center font-mono text-xs font-black">{item.quantity}</td>

                  <td className="py-3 px-4 text-right font-mono text-xs font-black text-orange-600">
                    {(item.weightLbs * item.quantity).toFixed(1)}
                  </td>

                  <td className="py-3 px-4 text-xs font-black text-emerald-900 uppercase flex items-center space-x-1">
                    <Users className="w-3.5 h-3.5 text-emerald-700" />
                    <span>{item.assignedTo}</span>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-emerald-800 hover:text-rose-600 transition font-black"
                      title="Delete item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Custom Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-emerald-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border-4 border-emerald-900 rounded-3xl max-w-md w-full p-6 shadow-[10px_10px_0px_0px_rgba(6,78,59,1)] space-y-4">
            <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Add Equipment Item</h3>

            <form onSubmit={handleAddGearItem} className="space-y-3">
              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Equipment Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Down Camp Slippers"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Gear Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as 'group' | 'personal')}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    <option value="group">Group Equipment</option>
                    <option value="personal">Personal Equipment</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  >
                    {categories.filter(c => c !== 'All').map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={newQuantity}
                    onChange={(e) => setNewQuantity(Number(e.target.value))}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Weight (lbs)</label>
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    value={newWeight}
                    onChange={(e) => setNewWeight(Number(e.target.value))}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Assigned To / Hiker Name</label>
                <input
                  type="text"
                  value={newAssigned}
                  onChange={(e) => setNewAssigned(e.target.value)}
                  placeholder="e.g. Alex"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="flex items-center space-x-2 pt-1">
                <input
                  type="checkbox"
                  id="essentialCheck"
                  checked={newIsEssential}
                  onChange={(e) => setNewIsEssential(e.target.checked)}
                  className="rounded border-emerald-900 text-orange-500 focus:ring-orange-500"
                />
                <label htmlFor="essentialCheck" className="text-xs font-black text-emerald-900 uppercase">
                  Mark as Non-Negotiable Essential
                </label>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 border-2 border-emerald-900 rounded-xl text-xs font-black uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-500 hover:bg-orange-400 text-white rounded-xl text-xs font-black uppercase border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
                >
                  Add Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
