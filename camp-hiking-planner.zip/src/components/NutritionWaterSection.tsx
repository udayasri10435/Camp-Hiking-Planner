import React from 'react';
import { ExpeditionPlan, MealPlanDay } from '../types';
import {
  Utensils,
  Droplets,
  Zap,
  Coffee,
  Flame,
  CheckCircle,
  Plus
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const NutritionWaterSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const handleUpdateMeal = (dayId: string, field: keyof MealPlanDay, value: string) => {
    const updatedMeals = plan.mealPlan.map((m) =>
      m.id === dayId ? { ...m, [field]: value } : m
    );
    onUpdatePlan({ mealPlan: updatedMeals });
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-amber-500 rounded-lg text-white border-2 border-emerald-900">
              <Utensils className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">7. Nutrition & Water Management</h2>
          </div>

          <div className="flex items-center space-x-4 bg-emerald-50 px-4 py-2 rounded-2xl border-2 border-emerald-900 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
            <div>
              <span className="text-[10px] font-black text-emerald-900 uppercase block">Daily Calorie Target</span>
              <span className="text-sm font-black text-orange-600 font-mono">
                {plan.dailyCaloriesTarget} kcal/day
              </span>
            </div>
            <div className="h-6 w-0.5 bg-emerald-900" />
            <div>
              <span className="text-[10px] font-black text-emerald-900 uppercase block">Water Capacity</span>
              <span className="text-sm font-black text-sky-700 font-mono">
                {plan.waterCapacityQuarts} Quarts / Hiker
              </span>
            </div>
          </div>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-6">
          Plan for 2,500–3,500 calories per day depending on elevation gain and activity. Prioritize nutrient-dense, lightweight freeze-dried rations, plus morale boosters.
        </p>

        {/* Targets Adjustment Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <label className="text-xs text-emerald-900 font-black uppercase block mb-1 flex items-center space-x-1">
              <Zap className="w-3.5 h-3.5 text-orange-600" />
              <span>Target Calories / Day</span>
            </label>
            <input
              type="number"
              step="100"
              value={plan.dailyCaloriesTarget}
              onChange={(e) => onUpdatePlan({ dailyCaloriesTarget: Number(e.target.value) })}
              className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-black text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
            />
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <label className="text-xs text-emerald-900 font-black uppercase block mb-1 flex items-center space-x-1">
              <Droplets className="w-3.5 h-3.5 text-sky-600" />
              <span>Water Capacity (Quarts)</span>
            </label>
            <input
              type="number"
              step="0.5"
              value={plan.waterCapacityQuarts}
              onChange={(e) => onUpdatePlan({ waterCapacityQuarts: Number(e.target.value) })}
              className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-black text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
            />
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <label className="text-xs text-emerald-900 font-black uppercase block mb-1 flex items-center space-x-1">
              <Flame className="w-3.5 h-3.5 text-emerald-900" />
              <span>Water Treatment Method</span>
            </label>
            <input
              type="text"
              value={plan.waterTreatmentMethod}
              onChange={(e) => onUpdatePlan({ waterTreatmentMethod: e.target.value })}
              className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-black text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>
        </div>

        {/* Day-by-Day Meal Matrix */}
        <div className="space-y-4">
          <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight flex items-center space-x-2">
            <Coffee className="w-5 h-5 text-orange-600" />
            <span>Daily Expedition Meal Breakdown</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {plan.mealPlan.map((mealDay) => (
              <div
                key={mealDay.id}
                className="bg-white p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-3"
              >
                <div className="flex items-center justify-between border-b-2 border-emerald-100 pb-2">
                  <span className="text-xs font-black text-emerald-900 uppercase">
                    Day {mealDay.dayNumber} Menu
                  </span>
                  <span className="text-[10px] font-mono font-black text-orange-600 bg-orange-100 px-2 py-0.5 rounded border border-orange-300">
                    ~{plan.dailyCaloriesTarget} kcal
                  </span>
                </div>

                <div>
                  <label className="text-[11px] font-black text-orange-600 uppercase block mb-0.5">
                    Breakfast
                  </label>
                  <textarea
                    rows={2}
                    value={mealDay.breakfast}
                    onChange={(e) => handleUpdateMeal(mealDay.id, 'breakfast', e.target.value)}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-black text-emerald-900 uppercase block mb-0.5">
                    Lunch / Trail Food
                  </label>
                  <textarea
                    rows={2}
                    value={mealDay.lunch}
                    onChange={(e) => handleUpdateMeal(mealDay.id, 'lunch', e.target.value)}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-black text-sky-700 uppercase block mb-0.5">
                    Dinner
                  </label>
                  <textarea
                    rows={2}
                    value={mealDay.dinner}
                    onChange={(e) => handleUpdateMeal(mealDay.id, 'dinner', e.target.value)}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-black text-emerald-800 uppercase block mb-0.5">
                    Snacks & Morale Boosters
                  </label>
                  <textarea
                    rows={2}
                    value={mealDay.snacks}
                    onChange={(e) => handleUpdateMeal(mealDay.id, 'snacks', e.target.value)}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
