import React, { useState } from 'react';
import { ExpeditionPlan } from '../types';
import {
  FileText,
  Target,
  Users,
  Compass,
  Tag,
  Edit2,
  Check,
  Award,
  Sparkles,
  Layers,
  Calendar,
  MapPin
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const ExecutiveSummarySection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const [isEditingSummary, setIsEditingSummary] = useState(false);
  const [summaryText, setSummaryText] = useState(plan.executiveSummary);
  const [newTheme, setNewTheme] = useState('');

  const handleSaveSummary = () => {
    onUpdatePlan({ executiveSummary: summaryText });
    setIsEditingSummary(false);
  };

  const handleAddTheme = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTheme.trim()) return;
    const updatedThemes = [...plan.keyThemes, newTheme.trim()];
    onUpdatePlan({ keyThemes: updatedThemes });
    setNewTheme('');
  };

  const handleRemoveTheme = (themeToRemove: string) => {
    const updatedThemes = plan.keyThemes.filter((t) => t !== themeToRemove);
    onUpdatePlan({ keyThemes: updatedThemes });
  };

  return (
    <div className="space-y-6">
      {/* Quick Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border-4 border-emerald-900 rounded-2xl p-4 shadow-[5px_5px_0px_0px_rgba(6,78,59,1)]">
          <div className="flex items-center space-x-2 text-emerald-800 mb-1">
            <Calendar className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-black uppercase text-emerald-800">Duration & Date</span>
          </div>
          <p className="text-lg font-black text-emerald-950">{plan.tripDuration}</p>
          <p className="text-xs font-bold text-emerald-700">{plan.date}</p>
        </div>

        <div className="bg-white border-4 border-emerald-900 rounded-2xl p-4 shadow-[5px_5px_0px_0px_rgba(6,78,59,1)]">
          <div className="flex items-center space-x-2 text-emerald-800 mb-1">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-black uppercase text-emerald-800">Location</span>
          </div>
          <p className="text-lg font-black text-emerald-950 truncate">{plan.locationName}</p>
          <p className="text-xs font-bold text-emerald-700">Basecamp & Trailhead</p>
        </div>

        <div className="bg-white border-4 border-emerald-900 rounded-2xl p-4 shadow-[5px_5px_0px_0px_rgba(6,78,59,1)]">
          <div className="flex items-center space-x-2 text-emerald-800 mb-1">
            <Users className="w-4 h-4 text-sky-600" />
            <span className="text-xs font-black uppercase text-emerald-800">Group Size</span>
          </div>
          <p className="text-lg font-black text-emerald-950">{plan.groupSize}</p>
          <p className="text-xs font-bold text-emerald-700 truncate">{plan.groupProfile}</p>
        </div>

        <div className="bg-white border-4 border-emerald-900 rounded-2xl p-4 shadow-[5px_5px_0px_0px_rgba(6,78,59,1)]">
          <div className="flex items-center space-x-2 text-emerald-800 mb-1">
            <Award className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-black uppercase text-emerald-800">Primary Goal</span>
          </div>
          <p className="text-sm font-black text-emerald-950 line-clamp-2">{plan.primaryObjective}</p>
        </div>
      </div>

      {/* Main Metadata Banner */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-4 border-b-2 border-emerald-100">
          <div>
            <label className="text-xs font-black text-emerald-800 uppercase tracking-wider">Proposal Title</label>
            <input
              type="text"
              value={plan.title}
              onChange={(e) => onUpdatePlan({ title: e.target.value })}
              className="w-full mt-1 bg-emerald-50/80 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-black text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>
          <div>
            <label className="text-xs font-black text-emerald-800 uppercase tracking-wider">Prepared For</label>
            <input
              type="text"
              value={plan.preparedFor}
              onChange={(e) => onUpdatePlan({ preparedFor: e.target.value })}
              className="w-full mt-1 bg-emerald-50/80 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>
          <div>
            <label className="text-xs font-black text-emerald-800 uppercase tracking-wider">Prepared By</label>
            <input
              type="text"
              value={plan.preparedBy}
              onChange={(e) => onUpdatePlan({ preparedBy: e.target.value })}
              className="w-full mt-1 bg-emerald-50/80 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>
        </div>

        {/* 1. Executive Summary Box */}
        <div className="mt-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-orange-500 rounded-lg text-white border-2 border-emerald-900">
                <FileText className="w-5 h-5" />
              </div>
              <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">1. Executive Summary</h2>
            </div>
            {isEditingSummary ? (
              <button
                onClick={handleSaveSummary}
                className="flex items-center space-x-1 text-xs font-black uppercase bg-emerald-900 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save Summary</span>
              </button>
            ) : (
              <button
                onClick={() => setIsEditingSummary(true)}
                className="flex items-center space-x-1 text-xs font-black uppercase bg-emerald-100 hover:bg-emerald-200 text-emerald-950 px-3 py-1.5 rounded-xl border-2 border-emerald-900 transition"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            )}
          </div>

          {isEditingSummary ? (
            <textarea
              rows={5}
              value={summaryText}
              onChange={(e) => setSummaryText(e.target.value)}
              className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-2xl p-4 text-emerald-950 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 leading-relaxed"
            />
          ) : (
            <p className="text-emerald-950 text-sm font-medium leading-relaxed bg-orange-50 p-5 rounded-2xl border-2 border-emerald-900">
              {plan.executiveSummary}
            </p>
          )}
        </div>
      </div>

      {/* 2. Expedition Overview & Objectives Table */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)] space-y-6">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3">
          <div className="p-1.5 bg-sky-500 rounded-lg text-white border-2 border-emerald-900">
            <Target className="w-5 h-5" />
          </div>
          <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">2. Expedition Overview & Objectives</h2>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide">
          The core purpose guides all subsequent decisions—from location selection and pacing to essential gear and safety protocols.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-emerald-100 text-emerald-900 border-b-2 border-emerald-900 font-black text-xs uppercase tracking-wider">
                <th className="py-3 px-4 w-1/4">Element</th>
                <th className="py-3 px-4">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-emerald-100 text-emerald-950">
              <tr>
                <td className="py-3 px-4 font-black text-emerald-900 flex items-center space-x-2 uppercase">
                  <Target className="w-4 h-4 text-orange-500" />
                  <span>Primary Objective</span>
                </td>
                <td className="py-3 px-4">
                  <input
                    type="text"
                    value={plan.primaryObjective}
                    onChange={(e) => onUpdatePlan({ primaryObjective: e.target.value })}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-black text-emerald-900 flex items-center space-x-2 uppercase">
                  <Users className="w-4 h-4 text-sky-600" />
                  <span>Group Size & Profile</span>
                </td>
                <td className="py-3 px-4 space-y-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={plan.groupSize}
                      onChange={(e) => onUpdatePlan({ groupSize: e.target.value })}
                      placeholder="e.g. 6 participants"
                      className="bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <input
                      type="text"
                      value={plan.groupProfile}
                      onChange={(e) => onUpdatePlan({ groupProfile: e.target.value })}
                      placeholder="e.g. Mixed experience levels"
                      className="bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </div>
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-black text-emerald-900 flex items-center space-x-2 uppercase">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  <span>Trip Type</span>
                </td>
                <td className="py-3 px-4">
                  <input
                    type="text"
                    value={plan.tripType}
                    onChange={(e) => onUpdatePlan({ tripType: e.target.value })}
                    placeholder="e.g. Basecamp with day hikes"
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-black text-emerald-900 flex items-center space-x-2 uppercase">
                  <Tag className="w-4 h-4 text-amber-500" />
                  <span>Key Themes</span>
                </td>
                <td className="py-3 px-4 space-y-3">
                  <div className="flex flex-wrap gap-2">
                    {plan.keyThemes.map((theme, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center space-x-1 bg-white border-2 border-emerald-900 text-emerald-950 text-xs font-black uppercase px-3 py-1 rounded-full shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
                      >
                        <span>{theme}</span>
                        <button
                          onClick={() => handleRemoveTheme(theme)}
                          className="text-orange-600 hover:text-orange-800 ml-1 font-black"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>

                  <form onSubmit={handleAddTheme} className="flex space-x-2">
                    <input
                      type="text"
                      value={newTheme}
                      onChange={(e) => setNewTheme(e.target.value)}
                      placeholder="Add key theme (e.g., Navigation)..."
                      className="bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    <button
                      type="submit"
                      className="bg-emerald-900 hover:bg-emerald-800 text-white border-2 border-emerald-950 px-3 py-1.5 rounded-xl text-xs font-black uppercase shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition"
                    >
                      + Add
                    </button>
                  </form>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
