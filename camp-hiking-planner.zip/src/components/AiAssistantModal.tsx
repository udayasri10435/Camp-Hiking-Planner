import React, { useState } from 'react';
import { ExpeditionPlan } from '../types';
import {
  Sparkles,
  X,
  Send,
  Bot,
  User as UserIcon,
  Compass,
  AlertTriangle,
  Scale,
  Utensils,
  ShieldCheck,
  Loader2
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  plan: ExpeditionPlan;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
}

export const AiAssistantModal: React.FC<Props> = ({ isOpen, onClose, plan }) => {
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      sender: 'ai',
      text: `Hello! I am your **AI Trail Advisor** powered by Gemini.

I can analyze your trip to **${plan.locationName}** and assist you with:
- **Weather & Mountain Hazard Assessment**
- **Gear Weight Optimization**
- **Calorie & High-Energy Meal Recommendations**
- **Leave No Trace & Wildlife Protocols**

How can I help you refine your proposal?`
    }
  ]);
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSend = async (userQuery?: string) => {
    const queryToSend = userQuery || prompt;
    if (!queryToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: queryToSend
    };

    setMessages((prev) => [...prev, userMsg]);
    setPrompt('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai/advise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: queryToSend,
          context: {
            title: plan.title,
            location: plan.locationName,
            duration: plan.tripDuration,
            groupSize: plan.groupSize,
            primaryObjective: plan.primaryObjective,
            dailyCalories: plan.dailyCaloriesTarget,
            gearCount: plan.gearItems.length
          }
        })
      });

      const data = await res.json();
      if (res.ok && data.reply) {
        const aiMsg: ChatMessage = {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: data.reply
        };
        setMessages((prev) => [...prev, aiMsg]);
      } else {
        throw new Error(data.error || 'Failed to fetch AI response');
      }
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          sender: 'ai',
          text: `⚠️ **Service Error:** ${err.message || 'Unable to connect to AI server.'}`
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    { label: 'Check Weather Hazards', query: 'Evaluate mountain weather risks and low-temperature gear advice for this trip.' },
    { label: 'Optimize Gear Weight', query: 'Analyze gear weight distribution and recommend lightweight alternatives.' },
    { label: '3,200 kcal Meal Plan', query: 'Suggest high-calorie lightweight freeze-dried meal options for 3 days.' },
    { label: 'Review Safety Triggers', query: 'Provide backup route trigger conditions for unexpected mountain storms.' }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-emerald-950/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white border-4 border-emerald-900 rounded-3xl w-full max-w-2xl h-[85vh] flex flex-col shadow-[8px_8px_0px_0px_rgba(6,78,59,1)] overflow-hidden">
        {/* Header */}
        <div className="bg-emerald-100 px-6 py-4 border-b-2 border-emerald-900 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-orange-500 text-white rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-emerald-950 uppercase flex items-center space-x-2">
                <span>AI Trail Advisor</span>
                <span className="text-[10px] bg-orange-500 text-white border border-emerald-950 px-2 py-0.5 rounded-full font-mono font-black">
                  Gemini 2.5
                </span>
              </h3>
              <p className="text-xs font-bold text-emerald-800 uppercase">Outdoor expedition assistant & safety consultant</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-emerald-950 hover:text-orange-600 rounded-xl hover:bg-emerald-200 transition font-black"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Prompts Bar */}
        <div className="bg-emerald-50 px-4 py-2.5 border-b-2 border-emerald-900 flex items-center space-x-2 overflow-x-auto scrollbar-none">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(qp.query)}
              disabled={loading}
              className="text-[11px] font-black uppercase bg-white hover:bg-orange-500 hover:text-white text-emerald-950 border-2 border-emerald-900 px-3 py-1 rounded-full whitespace-nowrap transition shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] disabled:opacity-50"
            >
              {qp.label}
            </button>
          ))}
        </div>

        {/* Chat Messages Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-white">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex space-x-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-emerald-900 text-white border-2 border-emerald-950 flex items-center justify-center shrink-0 mt-1 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed font-bold ${
                  msg.sender === 'user'
                    ? 'bg-orange-500 text-white border-2 border-emerald-950 rounded-tr-none shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]'
                    : 'bg-emerald-50 text-emerald-950 border-2 border-emerald-900 rounded-tl-none whitespace-pre-wrap shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]'
                }`}
              >
                {msg.text}
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-orange-500 text-white border-2 border-emerald-950 flex items-center justify-center shrink-0 mt-1 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
                  <UserIcon className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center space-x-2 text-emerald-900 font-bold text-xs py-2">
              <Loader2 className="w-4 h-4 animate-spin text-orange-600" />
              <span>Analyzing trail context & generating advice...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="bg-emerald-100 p-4 border-t-2 border-emerald-900">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask AI Trail Advisor about weather, packing, meals, or safety..."
              className="flex-1 bg-white border-2 border-emerald-900 rounded-xl px-4 py-2.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="p-2.5 bg-orange-500 hover:bg-orange-400 text-white rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
