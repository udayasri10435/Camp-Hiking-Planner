import React from 'react';
import { ExpeditionPlan } from '../types';
import {
  CheckCircle2,
  Wrench,
  Search,
  MessageSquare,
  Image,
  ExternalLink,
  Sparkles
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const PostTripSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="p-1.5 bg-emerald-900 rounded-lg text-white border-2 border-emerald-950">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">10. Post-Trip Action Plan & Wrap-Up</h2>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-6">
          The trip doesn't end when leaving the trail. A structured wrap-up helps consolidate lessons learned, repair gear, and share memories.
        </p>

        {/* 4 Post-Trip Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Pillar 1: Equipment Check */}
          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-emerald-900">
                <Wrench className="w-4 h-4 text-orange-600" />
                <h3 className="text-sm font-black uppercase text-emerald-900">1. Equipment Inspection & Repair</h3>
              </div>
              <input
                type="checkbox"
                checked={plan.equipmentCheckComplete}
                onChange={(e) => onUpdatePlan({ equipmentCheckComplete: e.target.checked })}
                className="rounded-lg border-2 border-emerald-900 text-orange-500 focus:ring-orange-500 w-5 h-5 accent-orange-500"
              />
            </div>
            <p className="text-xs font-bold text-emerald-900">
              Clean, dry, and inspect all tents, stoves, and sleeping gear before long-term storage. Log any items requiring repair or replacement.
            </p>
          </div>

          {/* Pillar 2: Site Inspection */}
          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 text-emerald-900">
                <Search className="w-4 h-4 text-sky-600" />
                <h3 className="text-sm font-black uppercase text-emerald-900">2. Campsite Grid Sweep</h3>
              </div>
              <input
                type="checkbox"
                checked={plan.siteInspectionDone}
                onChange={(e) => onUpdatePlan({ siteInspectionDone: e.target.checked })}
                className="rounded-lg border-2 border-emerald-900 text-orange-500 focus:ring-orange-500 w-5 h-5 accent-orange-500"
              />
            </div>
            <p className="text-xs font-bold text-emerald-900">
              Ensure campsite is cleaner than found. Perform final micro-trash inspection around fire pit and tent footprints.
            </p>
          </div>
        </div>

        {/* Pillar 3 & 4: Debrief Notes & Media Sharing */}
        <div className="mt-6 space-y-4">
          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-2">
            <div className="flex items-center space-x-2 text-emerald-900">
              <MessageSquare className="w-4 h-4 text-orange-600" />
              <h3 className="text-sm font-black uppercase text-emerald-900">3. Group Debrief & Feedback Notes</h3>
            </div>
            <textarea
              rows={4}
              value={plan.debriefNotes}
              onChange={(e) => onUpdatePlan({ debriefNotes: e.target.value })}
              placeholder="What worked well? What would you do differently next time? Pacing, meals, gear notes..."
              className="w-full bg-white border-2 border-emerald-900 rounded-xl p-3 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
            />
          </div>

          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-2">
            <div className="flex items-center space-x-2 text-emerald-900">
              <Image className="w-4 h-4 text-amber-600" />
              <h3 className="text-sm font-black uppercase text-emerald-900">4. Shared Photo Folder & Memories</h3>
            </div>
            <div className="flex space-x-2">
              <input
                type="text"
                value={plan.photoAlbumUrl}
                onChange={(e) => onUpdatePlan({ photoAlbumUrl: e.target.value })}
                placeholder="https://photos.app.goo.gl/..."
                className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              {plan.photoAlbumUrl && (
                <a
                  href={plan.photoAlbumUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-orange-500 hover:bg-orange-400 text-white font-black uppercase px-4 py-2 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] text-xs flex items-center space-x-1 shrink-0 transition"
                >
                  <span>Open Gallery</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
