import React from 'react';
import { ExpeditionPlan } from '../types';
import {
  MapPin,
  Clock,
  FileCheck,
  CloudSun,
  Droplets,
  Mountain,
  Shield,
  ExternalLink,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const LocationTimingSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center justify-between border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-orange-500 rounded-lg text-white border-2 border-emerald-900">
              <MapPin className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">3. Location & Timing Strategy</h2>
          </div>
          <span className={`text-xs border-2 border-emerald-950 px-3 py-1 rounded-full font-black uppercase shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] ${
            plan.permitsSecured ? 'bg-emerald-900 text-white' : 'bg-orange-500 text-white'
          }`}>
            Permits: {plan.permitsSecured ? 'Secured' : 'Action Required'}
          </span>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-6">
          Location parameters must align with group experience. Highlighting terrain variety, water source reliability, ranger patrols, and shoulder-season weather patterns.
        </p>

        {/* Location Form Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <label className="text-xs font-black text-emerald-900 flex items-center space-x-1.5 mb-1 uppercase tracking-wide">
                <Mountain className="w-4 h-4 text-orange-600" />
                <span>Location / Trailhead Name</span>
              </label>
              <input
                type="text"
                value={plan.locationName}
                onChange={(e) => onUpdatePlan({ locationName: e.target.value })}
                className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-2 text-emerald-950 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 flex items-center space-x-1.5 mb-1 uppercase tracking-wide">
                <Mountain className="w-4 h-4 text-emerald-700" />
                <span>Terrain & Trail Variety</span>
              </label>
              <textarea
                rows={3}
                value={plan.terrainVariety}
                onChange={(e) => onUpdatePlan({ terrainVariety: e.target.value })}
                className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-3 text-emerald-950 font-bold text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 flex items-center space-x-1.5 mb-1 uppercase tracking-wide">
                <Droplets className="w-4 h-4 text-sky-600" />
                <span>Water Sources & Access Strategy</span>
              </label>
              <textarea
                rows={3}
                value={plan.waterAccess}
                onChange={(e) => onUpdatePlan({ waterAccess: e.target.value })}
                className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-3 text-emerald-950 font-bold text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-xs font-black text-emerald-900 flex items-center space-x-1.5 mb-1 uppercase tracking-wide">
                <CloudSun className="w-4 h-4 text-amber-500" />
                <span>Seasonal Weather Strategy & Temperature Extremes</span>
              </label>
              <textarea
                rows={3}
                value={plan.seasonalWeather}
                onChange={(e) => onUpdatePlan({ seasonalWeather: e.target.value })}
                className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-3 text-emerald-950 font-bold text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 flex items-center space-x-1.5 mb-1 uppercase tracking-wide">
                <Shield className="w-4 h-4 text-rose-600" />
                <span>Permits & Reservations Requirements</span>
              </label>
              <textarea
                rows={3}
                value={plan.permitRequirements}
                onChange={(e) => onUpdatePlan({ permitRequirements: e.target.value })}
                className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-3 text-emerald-950 font-bold text-xs focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Permits & Reservations Documentation Tracker */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="p-1.5 bg-emerald-900 rounded-lg text-white border-2 border-emerald-950">
            <FileCheck className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Permits Verification & Documentation</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center bg-orange-50 p-4 rounded-2xl border-2 border-emerald-900">
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => onUpdatePlan({ permitsSecured: !plan.permitsSecured })}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-black text-xs uppercase border-2 border-emerald-950 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] transition ${
                plan.permitsSecured
                  ? 'bg-emerald-900 text-white'
                  : 'bg-orange-500 text-white'
              }`}
            >
              {plan.permitsSecured ? (
                <>
                  <CheckCircle className="w-4 h-4 text-white" />
                  <span>Permits Confirmed & Paid</span>
                </>
              ) : (
                <>
                  <AlertCircle className="w-4 h-4 text-white" />
                  <span>Permits Pending / Action Needed</span>
                </>
              )}
            </button>
          </div>

          <div>
            <label className="text-xs text-emerald-900 font-black uppercase block mb-1">Permit Documentation URL / Ref</label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={plan.permitDocLink}
                onChange={(e) => onUpdatePlan({ permitDocLink: e.target.value })}
                placeholder="https://example.com/permit.pdf"
                className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs text-emerald-950 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              {plan.permitDocLink && (
                <a
                  href={plan.permitDocLink}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-emerald-900 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-xl border-2 border-emerald-950 flex items-center space-x-1 text-xs font-black uppercase shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
                >
                  <span>Open</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
