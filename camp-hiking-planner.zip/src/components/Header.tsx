import React from 'react';
import {
  Compass,
  Sparkles,
  Printer,
  Cloud,
  CloudCheck,
  User as UserIcon,
  LogOut,
  LogIn,
  PlusCircle,
  FileText
} from 'lucide-react';
import { User } from 'firebase/auth';
import { signInWithGoogle, logoutUser } from '../lib/firebase';

interface HeaderProps {
  user: User | null;
  authLoading: boolean;
  isSynced: boolean;
  activePlanTitle: string;
  onOpenAiModal: () => void;
  onOpenPrintModal: () => void;
  onResetToDefault: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  authLoading,
  isSynced,
  activePlanTitle,
  onOpenAiModal,
  onOpenPrintModal,
  onResetToDefault,
}) => {
  return (
    <header className="bg-emerald-900 text-white border-b-4 border-emerald-950 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand & Active Plan Title */}
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-orange-500 text-white rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
            <Compass className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-lg font-black tracking-tight text-white uppercase sm:text-xl">
                Camp Hiking Planner
              </h1>
              <span className="hidden md:inline-block text-[10px] bg-white text-emerald-950 border-2 border-emerald-950 px-2.5 py-0.5 rounded-full font-black uppercase">
                Proposal v2.4
              </span>
            </div>
            <p className="text-xs text-emerald-200 font-bold uppercase tracking-wider hidden sm:block truncate max-w-xs sm:max-w-md">
              {activePlanTitle}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2 sm:space-x-3">
          {/* Sync Status Indicator */}
          <div
            className={`hidden lg:flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-black uppercase border-2 border-emerald-950 ${
              isSynced
                ? 'bg-emerald-950 text-emerald-300'
                : 'bg-orange-600 text-white'
            }`}
            title={isSynced ? 'Synced to Firestore Cloud' : 'Local Draft / Saving...'}
          >
            {isSynced ? (
              <>
                <CloudCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cloud Synced</span>
              </>
            ) : (
              <>
                <Cloud className="w-3.5 h-3.5 text-white" />
                <span>Local Draft</span>
              </>
            )}
          </div>

          {/* Reset proposal template */}
          <button
            onClick={onResetToDefault}
            className="flex items-center space-x-1 text-xs font-black uppercase bg-white hover:bg-emerald-100 text-emerald-950 px-2.5 py-1.5 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition active:translate-y-0.5"
            title="Load standard proposal template"
          >
            <FileText className="w-3.5 h-3.5 text-emerald-900" />
            <span className="hidden sm:inline">Load Template</span>
          </button>

          {/* AI Advisor Button */}
          <button
            onClick={onOpenAiModal}
            className="flex items-center space-x-1.5 text-xs font-black uppercase bg-orange-500 hover:bg-orange-400 text-white px-3 py-1.5 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition active:translate-y-0.5"
          >
            <Sparkles className="w-4 h-4 text-white animate-spin-slow" />
            <span className="hidden sm:inline">AI Advisor</span>
            <span className="sm:hidden">AI</span>
          </button>

          {/* Print/Export Button */}
          <button
            onClick={onOpenPrintModal}
            className="flex items-center space-x-1 text-xs font-black uppercase bg-sky-500 hover:bg-sky-400 text-white px-3 py-1.5 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition active:translate-y-0.5"
            title="Print or view formatted proposal"
          >
            <Printer className="w-4 h-4 text-white" />
            <span className="hidden md:inline">Print / Save</span>
          </button>

          {/* Firebase Google Auth */}
          <div className="pl-1 border-l-2 border-emerald-800">
            {authLoading ? (
              <div className="w-8 h-8 rounded-full bg-emerald-800 animate-pulse border-2 border-emerald-950" />
            ) : user ? (
              <div className="flex items-center space-x-2">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-8 h-8 rounded-full border-2 border-emerald-950 shadow"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-orange-500 text-white border-2 border-emerald-950 flex items-center justify-center font-black text-xs">
                    {(user.displayName || user.email || 'U').charAt(0).toUpperCase()}
                  </div>
                )}
                <button
                  onClick={logoutUser}
                  className="p-1.5 text-emerald-200 hover:text-white hover:bg-emerald-800 rounded-lg border-2 border-transparent hover:border-emerald-950 transition"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="flex items-center space-x-1.5 text-xs font-black uppercase bg-white hover:bg-emerald-100 text-emerald-950 px-3 py-1.5 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition"
              >
                <LogIn className="w-4 h-4 text-orange-600" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
