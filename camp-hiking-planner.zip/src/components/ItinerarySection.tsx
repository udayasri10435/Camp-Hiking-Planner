import React, { useState } from 'react';
import { ExpeditionPlan, ItineraryDay, ScheduleItem } from '../types';
import {
  Calendar,
  Clock,
  Plus,
  Trash2,
  CheckSquare,
  Square,
  MapPin,
  ChevronDown,
  ChevronUp,
  TrendingUp
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const ItinerarySection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const [selectedDayId, setSelectedDayId] = useState<string>(
    plan.itinerary.length > 0 ? plan.itinerary[0].id : ''
  );
  const [showAddModal, setShowAddModal] = useState(false);
  const [newItemTime, setNewItemTime] = useState('08:00 AM');
  const [newItemActivity, setNewItemActivity] = useState('');
  const [newItemDetails, setNewItemDetails] = useState('');
  const [newItemLocation, setNewItemLocation] = useState('');

  const activeDay = plan.itinerary.find((d) => d.id === selectedDayId) || plan.itinerary[0];

  const handleToggleScheduleItem = (dayId: string, itemId: string) => {
    const updatedItinerary = plan.itinerary.map((day) => {
      if (day.id !== dayId) return day;
      return {
        ...day,
        scheduleItems: day.scheduleItems.map((item) =>
          item.id === itemId ? { ...item, completed: !item.completed } : item
        )
      };
    });
    onUpdatePlan({ itinerary: updatedItinerary });
  };

  const handleAddScheduleItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemActivity.trim()) return;

    const newItem: ScheduleItem = {
      id: `item-${Date.now()}`,
      timeOfDay: newItemTime,
      activity: newItemActivity.trim(),
      details: newItemDetails.trim(),
      location: newItemLocation.trim() || undefined,
      completed: false
    };

    const updatedItinerary = plan.itinerary.map((day) => {
      if (day.id !== activeDay.id) return day;
      return {
        ...day,
        scheduleItems: [...day.scheduleItems, newItem]
      };
    });

    onUpdatePlan({ itinerary: updatedItinerary });
    setNewItemActivity('');
    setNewItemDetails('');
    setNewItemLocation('');
    setShowAddModal(false);
  };

  const handleDeleteScheduleItem = (dayId: string, itemId: string) => {
    const updatedItinerary = plan.itinerary.map((day) => {
      if (day.id !== dayId) return day;
      return {
        ...day,
        scheduleItems: day.scheduleItems.filter((item) => item.id !== itemId)
      };
    });
    onUpdatePlan({ itinerary: updatedItinerary });
  };

  const handleAddDay = () => {
    const nextDayNum = plan.itinerary.length + 1;
    const newDay: ItineraryDay = {
      id: `day-${nextDayNum}-${Date.now()}`,
      dayNumber: nextDayNum,
      title: `Day ${nextDayNum}: Exploration & Trek`,
      subtitle: 'Milestones, activities, and camp rest',
      scheduleItems: [
        {
          id: `item-init-${Date.now()}`,
          timeOfDay: '08:00 AM',
          activity: 'Morning Hike & Milestone',
          details: 'Begin day hike along trail.',
          location: 'Trail Junction',
          completed: false
        }
      ]
    };
    const updated = [...plan.itinerary, newDay];
    onUpdatePlan({ itinerary: updated });
    setSelectedDayId(newDay.id);
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-orange-500 rounded-lg text-white border-2 border-emerald-900">
              <Calendar className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">4. Multi-Day Itinerary Structure</h2>
          </div>
          <button
            onClick={handleAddDay}
            className="flex items-center space-x-1.5 text-xs font-black uppercase bg-orange-500 hover:bg-orange-400 text-white px-3.5 py-2 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition self-start sm:self-auto"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Day {plan.itinerary.length + 1}</span>
          </button>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-4">
          Alternates physical activity with rest buffers. Uses flexible milestone triggers rather than rigid time slots to accommodate fatigue, weather shifts, and discoveries.
        </p>

        {/* Day Selector Tabs */}
        <div className="flex space-x-2 overflow-x-auto pb-2 border-b-2 border-emerald-100">
          {plan.itinerary.map((day) => {
            const isSelected = day.id === activeDay?.id;
            const completedCount = day.scheduleItems.filter((i) => i.completed).length;
            return (
              <button
                key={day.id}
                onClick={() => setSelectedDayId(day.id)}
                className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-tight whitespace-nowrap transition flex items-center space-x-2 border-2 ${
                  isSelected
                    ? 'bg-orange-500 text-white border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]'
                    : 'bg-emerald-50 text-emerald-950 border-emerald-900 hover:bg-emerald-100'
                }`}
              >
                <span>Day {day.dayNumber}</span>
                <span className="text-[10px] font-mono">({completedCount}/{day.scheduleItems.length})</span>
              </button>
            );
          })}
        </div>

        {/* Active Day Header */}
        {activeDay && (
          <div className="mt-6 space-y-4">
            <div className="bg-orange-50 p-4 rounded-2xl border-2 border-emerald-900 flex flex-col md:flex-row md:items-center justify-between gap-2">
              <div>
                <input
                  type="text"
                  value={activeDay.title}
                  onChange={(e) => {
                    const newTitle = e.target.value;
                    const updated = plan.itinerary.map((d) =>
                      d.id === activeDay.id ? { ...d, title: newTitle } : d
                    );
                    onUpdatePlan({ itinerary: updated });
                  }}
                  className="bg-transparent text-lg font-black text-emerald-950 uppercase focus:outline-none focus:border-b-2 focus:border-orange-500 w-full"
                />
                <input
                  type="text"
                  value={activeDay.subtitle}
                  onChange={(e) => {
                    const newSub = e.target.value;
                    const updated = plan.itinerary.map((d) =>
                      d.id === activeDay.id ? { ...d, subtitle: newSub } : d
                    );
                    onUpdatePlan({ itinerary: updated });
                  }}
                  className="bg-transparent text-xs font-bold text-orange-600 uppercase tracking-wide focus:outline-none focus:border-b-2 focus:border-orange-500 w-full mt-0.5"
                />
              </div>

              <button
                onClick={() => setShowAddModal(true)}
                className="flex items-center space-x-1 text-xs font-black uppercase bg-white hover:bg-emerald-100 text-emerald-950 border-2 border-emerald-900 px-3 py-1.5 rounded-xl shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition self-start md:self-auto"
              >
                <Plus className="w-3.5 h-3.5 text-orange-500" />
                <span>Add Schedule Item</span>
              </button>
            </div>

            {/* Schedule Timeline Items */}
            <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-1 before:bg-emerald-900">
              {activeDay.scheduleItems.map((item) => (
                <div
                  key={item.id}
                  className={`relative pl-8 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] transition ${
                    item.completed
                      ? 'bg-emerald-100/60 opacity-80'
                      : 'bg-white'
                  }`}
                >
                  {/* Circle Marker */}
                  <button
                    onClick={() => handleToggleScheduleItem(activeDay.id, item.id)}
                    className={`absolute left-1.5 top-5 w-5 h-5 rounded-full border-2 border-emerald-950 flex items-center justify-center transition ${
                      item.completed
                        ? 'bg-emerald-900 text-white'
                        : 'bg-orange-500 text-white hover:bg-orange-400'
                    }`}
                  >
                    {item.completed && <CheckSquare className="w-3.5 h-3.5 text-white" />}
                  </button>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-mono font-black text-orange-600 flex items-center space-x-1 bg-orange-100 px-2 py-0.5 rounded border border-orange-300">
                        <Clock className="w-3 h-3" />
                        <span>{item.timeOfDay}</span>
                      </span>
                      <h4
                        className={`text-sm font-black uppercase tracking-tight ${
                          item.completed ? 'line-through text-emerald-800' : 'text-emerald-950'
                        }`}
                      >
                        {item.activity}
                      </h4>
                    </div>

                    <div className="flex items-center space-x-2">
                      {item.location && (
                        <span className="text-[11px] text-emerald-950 font-bold bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded flex items-center space-x-1">
                          <MapPin className="w-3 h-3 text-sky-600" />
                          <span>{item.location}</span>
                        </span>
                      )}

                      <button
                        onClick={() => handleDeleteScheduleItem(activeDay.id, item.id)}
                        className="text-emerald-800 hover:text-rose-600 p-1 transition font-black"
                        title="Delete item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs font-medium text-emerald-950 leading-relaxed mt-1">{item.details}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Elevation Profile & Trail Map Preview */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="p-1.5 bg-sky-500 rounded-lg text-white border-2 border-emerald-900">
            <TrendingUp className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Route & Elevation Profile Visualizer</h3>
        </div>

        <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 space-y-4">
          <div className="flex items-center justify-between text-xs font-black text-emerald-900 uppercase">
            <span>Trailhead (4,200 ft)</span>
            <span>Mirror Lake Basecamp (5,400 ft)</span>
            <span>Eagle Ridge (6,800 ft)</span>
          </div>

          <div className="h-24 w-full bg-white rounded-xl p-2 relative flex items-end justify-between overflow-hidden border-2 border-emerald-900">
            {/* Elevation Curves */}
            <svg className="absolute inset-0 w-full h-full text-emerald-500/20" preserveAspectRatio="none" viewBox="0 0 100 100">
              <path
                d="M 0,90 Q 25,60 50,45 T 75,10 T 100,85 L 100,100 L 0,100 Z"
                fill="currentColor"
              />
              <path
                d="M 0,90 Q 25,60 50,45 T 75,10 T 100,85"
                fill="none"
                stroke="#065f46"
                strokeWidth="3"
              />
            </svg>
            <div className="relative z-10 text-[10px] font-black uppercase text-emerald-950 bg-white px-2 py-0.5 rounded border-2 border-emerald-900 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]">
              Cumulative Gain: +2,600 ft | Total Trail: 13.2 Miles
            </div>
          </div>
        </div>
      </div>

      {/* Add Schedule Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-emerald-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border-4 border-emerald-900 rounded-3xl max-w-md w-full p-6 shadow-[10px_10px_0px_0px_rgba(6,78,59,1)] space-y-4">
            <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Add Schedule Milestone</h3>

            <form onSubmit={handleAddScheduleItem} className="space-y-3">
              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Time of Day</label>
                <input
                  type="text"
                  value={newItemTime}
                  onChange={(e) => setNewItemTime(e.target.value)}
                  placeholder="e.g. 02:00 PM"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Activity Title</label>
                <input
                  type="text"
                  value={newItemActivity}
                  onChange={(e) => setNewItemActivity(e.target.value)}
                  placeholder="e.g. Water Filtration & Break"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Location / Milestone</label>
                <input
                  type="text"
                  value={newItemLocation}
                  onChange={(e) => setNewItemLocation(e.target.value)}
                  placeholder="e.g. Creek Crossing #2"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Details & Safety Notes</label>
                <textarea
                  rows={3}
                  value={newItemDetails}
                  onChange={(e) => setNewItemDetails(e.target.value)}
                  placeholder="e.g. Refill water bladders, perform boot check..."
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl p-2 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 border-2 border-emerald-900 rounded-xl text-xs font-black uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-500 hover:bg-orange-400 text-white rounded-xl text-xs font-black uppercase border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
                >
                  Save Milestone
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
