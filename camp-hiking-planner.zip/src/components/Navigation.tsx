import React from 'react';
import {
  FileText,
  MapPin,
  Calendar,
  Backpack,
  ShieldAlert,
  Utensils,
  DollarSign,
  Leaf,
  CheckCircle2
} from 'lucide-react';

export type TabId =
  | 'summary'
  | 'location'
  | 'itinerary'
  | 'gear'
  | 'safety'
  | 'nutrition'
  | 'budget'
  | 'lnt'
  | 'posttrip';

interface NavigationProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  packedCount: number;
  totalGearCount: number;
  completedScheduleCount: number;
  totalScheduleCount: number;
  lntCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  packedCount,
  totalGearCount,
  completedScheduleCount,
  totalScheduleCount,
  lntCount
}) => {
  const tabs: { id: TabId; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'summary', label: '1. Executive Summary', icon: FileText },
    { id: 'location', label: '2. Location & Timing', icon: MapPin },
    {
      id: 'itinerary',
      label: '3. Itinerary',
      icon: Calendar,
      badge: `${completedScheduleCount}/${totalScheduleCount}`
    },
    {
      id: 'gear',
      label: '4. Gear & Packing',
      icon: Backpack,
      badge: `${packedCount}/${totalGearCount}`
    },
    { id: 'safety', label: '5. Safety & Risk', icon: ShieldAlert },
    { id: 'nutrition', label: '6. Nutrition & Water', icon: Utensils },
    { id: 'budget', label: '7. Budget & Logistics', icon: DollarSign },
    { id: 'lnt', label: '8. Leave No Trace', icon: Leaf, badge: `${lntCount}/7` },
    { id: 'posttrip', label: '9. Post-Trip Wrap-up', icon: CheckCircle2 }
  ];

  return (
    <nav className="bg-emerald-950 border-b-4 border-emerald-900 sticky top-16 z-20 overflow-x-auto scrollbar-none shadow-md py-2.5">
      <div className="max-w-7xl mx-auto px-4 flex space-x-1.5 sm:space-x-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-black uppercase tracking-tight whitespace-nowrap transition ${
                isActive
                  ? 'bg-orange-500 text-white border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] scale-[1.02]'
                  : 'text-emerald-100 hover:text-white hover:bg-emerald-900/80 border-2 border-transparent'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-emerald-300'}`} />
              <span>{tab.label}</span>
              {tab.badge && (
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                    isActive
                      ? 'bg-white text-emerald-950 border border-emerald-950'
                      : 'bg-emerald-900 text-emerald-200 border border-emerald-800'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
