import React, { useState } from 'react';
import { ExpeditionPlan, BudgetItem } from '../types';
import {
  DollarSign,
  Plus,
  Trash2,
  TrendingDown,
  TrendingUp,
  PieChart,
  Coins
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const BudgetSection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const [newEst, setNewEst] = useState(50);
  const [newAct, setNewAct] = useState(0);
  const [newNotes, setNewNotes] = useState('');

  const totalEst = plan.budgetItems.reduce((acc, item) => acc + item.estimatedCost, 0);
  const totalAct = plan.budgetItems.reduce((acc, item) => acc + item.actualCost, 0);
  const variance = totalEst - totalAct;

  const handleUpdateItem = (id: string, field: keyof BudgetItem, val: any) => {
    const updated = plan.budgetItems.map((item) =>
      item.id === id ? { ...item, [field]: val } : item
    );
    onUpdatePlan({ budgetItems: updated });
  };

  const handleDeleteItem = (id: string) => {
    const updated = plan.budgetItems.filter((i) => i.id !== id);
    onUpdatePlan({ budgetItems: updated });
  };

  const handleAddBudgetItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategory.trim()) return;

    const newItem: BudgetItem = {
      id: `b-${Date.now()}`,
      category: newCategory.trim(),
      estimatedCost: Number(newEst) || 0,
      actualCost: Number(newAct) || 0,
      notes: newNotes.trim()
    };

    onUpdatePlan({ budgetItems: [...plan.budgetItems, newItem] });
    setNewCategory('');
    setNewNotes('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Section Header & Summary Cards */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-emerald-900 rounded-lg text-white border-2 border-emerald-950">
              <DollarSign className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">8. Budget & Logistics Breakdown</h2>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center space-x-1.5 text-xs font-black uppercase bg-orange-500 hover:bg-orange-400 text-white px-3.5 py-2 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add Expense Category</span>
          </button>
        </div>

        {/* Financial Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <p className="text-xs font-black text-emerald-900 uppercase">Total Estimated Cost</p>
            <p className="text-2xl font-black text-emerald-950 font-mono mt-1">${totalEst.toFixed(2)}</p>
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
            <p className="text-xs font-black text-emerald-900 uppercase">Total Actual Spent</p>
            <p className="text-2xl font-black text-orange-600 font-mono mt-1">${totalAct.toFixed(2)}</p>
          </div>

          <div className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] flex items-center justify-between">
            <div>
              <p className="text-xs font-black text-emerald-900 uppercase">Remaining / Variance</p>
              <p
                className={`text-2xl font-black font-mono mt-1 ${
                  variance >= 0 ? 'text-emerald-700' : 'text-rose-600'
                }`}
              >
                {variance >= 0 ? `+$${variance.toFixed(2)}` : `-$${Math.abs(variance).toFixed(2)}`}
              </p>
            </div>
            {variance >= 0 ? (
              <TrendingDown className="w-6 h-6 text-emerald-700" />
            ) : (
              <TrendingUp className="w-6 h-6 text-rose-600" />
            )}
          </div>
        </div>

        {/* Budget Table */}
        <div className="overflow-x-auto rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)]">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="bg-emerald-100 text-emerald-950 border-b-2 border-emerald-900 text-xs uppercase font-black">
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Estimated Cost ($)</th>
                <th className="py-3 px-4 text-right">Actual Cost ($)</th>
                <th className="py-3 px-4">Notes & Allocation</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-emerald-100 bg-white text-emerald-950 font-bold">
              {plan.budgetItems.map((item) => (
                <tr key={item.id} className="hover:bg-emerald-50/50">
                  <td className="py-3 px-4 font-black uppercase text-emerald-900">{item.category}</td>

                  <td className="py-3 px-4 text-right font-mono">
                    <input
                      type="number"
                      step="5"
                      value={item.estimatedCost}
                      onChange={(e) =>
                        handleUpdateItem(item.id, 'estimatedCost', Number(e.target.value))
                      }
                      className="w-24 bg-emerald-50 border-2 border-emerald-900 rounded-xl px-2 py-1 text-right text-xs font-black text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                    />
                  </td>

                  <td className="py-3 px-4 text-right font-mono">
                    <input
                      type="number"
                      step="5"
                      value={item.actualCost}
                      onChange={(e) =>
                        handleUpdateItem(item.id, 'actualCost', Number(e.target.value))
                      }
                      className="w-24 bg-emerald-50 border-2 border-emerald-900 rounded-xl px-2 py-1 text-right text-xs font-black text-orange-600 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                    />
                  </td>

                  <td className="py-3 px-4 text-xs">
                    <input
                      type="text"
                      value={item.notes}
                      onChange={(e) => handleUpdateItem(item.id, 'notes', e.target.value)}
                      className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-2 py-1 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                  </td>

                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-emerald-800 hover:text-rose-600 p-1 font-black transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-emerald-100 font-black text-emerald-950 border-t-2 border-emerald-900 uppercase">
                <td className="py-3 px-4">TOTALS</td>
                <td className="py-3 px-4 text-right font-mono text-emerald-950">
                  ${totalEst.toFixed(2)}
                </td>
                <td className="py-3 px-4 text-right font-mono text-orange-600">
                  ${totalAct.toFixed(2)}
                </td>
                <td className="py-3 px-4 text-xs font-bold text-emerald-800">
                  Per person estimate: ~${(totalEst / 6).toFixed(2)} (based on 6 hikers)
                </td>
                <td className="py-3 px-4" />
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Fundraising Notes */}
        <div className="mt-6 bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-2">
          <label className="text-xs font-black text-emerald-900 uppercase flex items-center space-x-1.5">
            <Coins className="w-4 h-4 text-orange-600" />
            <span>Fundraising, Dues & Sponsorship Strategy</span>
          </label>
          <textarea
            rows={2}
            value={plan.fundraisingNotes}
            onChange={(e) => onUpdatePlan({ fundraisingNotes: e.target.value })}
            className="w-full bg-white border-2 border-emerald-900 rounded-xl p-2.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
        </div>
      </div>

      {/* Add Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-emerald-950/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border-4 border-emerald-900 rounded-3xl max-w-md w-full p-6 shadow-[8px_8px_0px_0px_rgba(6,78,59,1)] space-y-4">
            <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Add Budget Expense Line</h3>

            <form onSubmit={handleAddBudgetItem} className="space-y-3">
              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Expense Category</label>
                <input
                  type="text"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  placeholder="e.g. Shuttle Service / Fuel"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Estimated Cost ($)</label>
                  <input
                    type="number"
                    step="5"
                    value={newEst}
                    onChange={(e) => setNewEst(Number(e.target.value))}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>

                <div>
                  <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Actual Cost ($)</label>
                  <input
                    type="number"
                    step="5"
                    value={newAct}
                    onChange={(e) => setNewAct(Number(e.target.value))}
                    className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Notes / Breakdown</label>
                <input
                  type="text"
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="e.g. Split 3 ways between drivers"
                  className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3.5 py-1.5 bg-emerald-100 text-emerald-950 border-2 border-emerald-900 rounded-xl text-xs font-black uppercase"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-orange-500 text-white border-2 border-emerald-950 rounded-xl text-xs font-black uppercase shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
                >
                  Save Expense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
