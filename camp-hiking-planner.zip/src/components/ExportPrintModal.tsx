import React from 'react';
import { ExpeditionPlan } from '../types';
import { X, Printer, Compass, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  plan: ExpeditionPlan;
}

export const ExportPrintModal: React.FC<Props> = ({ isOpen, onClose, plan }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const totalBudgetEst = plan.budgetItems.reduce((acc, b) => acc + b.estimatedCost, 0);

  return (
    <div className="fixed inset-0 z-50 bg-emerald-950/70 backdrop-blur-sm flex items-center justify-center p-2 sm:p-6 overflow-y-auto">
      <div className="bg-white border-4 border-emerald-900 rounded-3xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-[8px_8px_0px_0px_rgba(6,78,59,1)] overflow-hidden">
        {/* Header toolbar */}
        <div className="bg-emerald-100 px-6 py-4 border-b-2 border-emerald-900 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-emerald-900 text-white rounded-lg border-2 border-emerald-950">
              <Printer className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-black text-emerald-950 uppercase tracking-tight">Proposal Print & Document View</h3>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1.5 bg-orange-500 hover:bg-orange-400 text-white px-4 py-2 rounded-xl text-xs font-black uppercase border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Save as PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-emerald-950 hover:text-orange-600 rounded-xl hover:bg-emerald-200 transition font-black"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Proposal Document Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10 bg-emerald-50/30 text-emerald-950 font-sans print:p-0 space-y-8">
          {/* Document Header */}
          <div className="border-b-4 border-emerald-900 pb-6">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-3xl font-black uppercase tracking-tight text-emerald-950">
                  {plan.title}
                </h1>
                <p className="text-sm font-black text-orange-600 mt-1 uppercase tracking-wider">
                  Full Expedition Proposal
                </p>
              </div>
              <div className="text-right text-xs font-bold text-emerald-900">
                <p><strong>Date:</strong> {plan.date}</p>
                <p><strong>Duration:</strong> {plan.tripDuration}</p>
                <p><strong>Location:</strong> {plan.locationName}</p>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t-2 border-emerald-200 grid grid-cols-2 gap-4 text-xs font-bold text-emerald-900">
              <p><strong>Prepared For:</strong> {plan.preparedFor}</p>
              <p><strong>Prepared By:</strong> {plan.preparedBy}</p>
            </div>
          </div>

          {/* 1. Executive Summary */}
          <section className="space-y-2">
            <h2 className="text-lg font-black text-emerald-950 uppercase border-b-2 border-emerald-900 pb-1">
              1. Executive Summary
            </h2>
            <p className="text-xs font-bold text-emerald-900 leading-relaxed">{plan.executiveSummary}</p>
          </section>

          {/* 2. Expedition Overview */}
          <section className="space-y-3">
            <h2 className="text-lg font-black text-emerald-950 uppercase border-b-2 border-emerald-900 pb-1">
              2. Expedition Overview & Objectives
            </h2>
            <table className="w-full text-xs text-left border-2 border-emerald-900 rounded-xl overflow-hidden bg-white">
              <tbody className="divide-y-2 divide-emerald-100 font-bold">
                <tr>
                  <td className="p-2.5 font-black uppercase bg-emerald-100 text-emerald-950 w-1/3">Primary Objective</td>
                  <td className="p-2.5 text-emerald-950">{plan.primaryObjective}</td>
                </tr>
                <tr>
                  <td className="p-2.5 font-black uppercase bg-emerald-100 text-emerald-950">Group Size & Profile</td>
                  <td className="p-2.5 text-emerald-950">{plan.groupSize} — {plan.groupProfile}</td>
                </tr>
                <tr>
                  <td className="p-2.5 font-black uppercase bg-emerald-100 text-emerald-950">Trip Type</td>
                  <td className="p-2.5 text-emerald-950">{plan.tripType}</td>
                </tr>
                <tr>
                  <td className="p-2.5 font-black uppercase bg-emerald-100 text-emerald-950">Key Themes</td>
                  <td className="p-2.5 text-emerald-950">{plan.keyThemes.join(', ')}</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* 3. Location & Timing Strategy */}
          <section className="space-y-3">
            <h2 className="text-lg font-black text-emerald-950 uppercase border-b-2 border-emerald-900 pb-1">
              3. Location & Timing Strategy
            </h2>
            <div className="grid grid-cols-2 gap-4 text-xs font-bold text-emerald-900">
              <div>
                <p className="font-black text-emerald-950 uppercase">Terrain & Variety:</p>
                <p>{plan.terrainVariety}</p>
              </div>
              <div>
                <p className="font-black text-emerald-950 uppercase">Water Access:</p>
                <p>{plan.waterAccess}</p>
              </div>
              <div>
                <p className="font-black text-emerald-950 uppercase">Seasonal Weather:</p>
                <p>{plan.seasonalWeather}</p>
              </div>
              <div>
                <p className="font-black text-emerald-950 uppercase">Permits & Reservations:</p>
                <p>{plan.permitRequirements}</p>
              </div>
            </div>
          </section>

          {/* 4. Multi-Day Itinerary Structure */}
          <section className="space-y-4">
            <h2 className="text-lg font-black text-emerald-950 uppercase border-b-2 border-emerald-900 pb-1">
              4. Multi-Day Itinerary Structure
            </h2>
            {plan.itinerary.map((day) => (
              <div key={day.id} className="border-2 border-emerald-900 rounded-2xl p-4 bg-white shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] space-y-2">
                <div className="font-black text-xs text-orange-600 uppercase border-b-2 border-emerald-100 pb-1">
                  Day {day.dayNumber}: {day.title} — <span className="font-bold lowercase italic text-emerald-900">{day.subtitle}</span>
                </div>
                <div className="space-y-1.5 pl-2">
                  {day.scheduleItems.map((item) => (
                    <div key={item.id} className="text-xs font-bold flex justify-between">
                      <span className="font-black text-emerald-950 w-24 shrink-0">{item.timeOfDay}</span>
                      <span className="font-bold text-emerald-900 flex-1">{item.activity}</span>
                      <span className="text-emerald-800 text-right">{item.location || ''}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </section>

          {/* 5. Budget Summary */}
          <section className="space-y-3">
            <h2 className="text-lg font-black text-emerald-950 uppercase border-b-2 border-emerald-900 pb-1">
              5. Financial Budget & Logistics
            </h2>
            <table className="w-full text-xs text-left border-2 border-emerald-900 rounded-xl overflow-hidden bg-white">
              <thead>
                <tr className="bg-emerald-100 font-black text-emerald-950 uppercase border-b-2 border-emerald-900">
                  <th className="p-2">Category</th>
                  <th className="p-2 text-right">Estimated ($)</th>
                  <th className="p-2">Notes</th>
                </tr>
              </thead>
              <tbody className="divide-y-2 divide-emerald-100 font-bold">
                {plan.budgetItems.map((b) => (
                  <tr key={b.id}>
                    <td className="p-2 font-black uppercase text-emerald-950">{b.category}</td>
                    <td className="p-2 text-right font-mono font-black text-orange-600">${b.estimatedCost.toFixed(2)}</td>
                    <td className="p-2 text-emerald-800">{b.notes}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-emerald-100 font-black text-emerald-950 uppercase border-t-2 border-emerald-900">
                  <td className="p-2">TOTAL ESTIMATED</td>
                  <td className="p-2 text-right font-mono text-orange-600">${totalBudgetEst.toFixed(2)}</td>
                  <td className="p-2" />
                </tr>
              </tfoot>
            </table>
          </section>

          {/* Sign-off */}
          <div className="pt-8 border-t-2 border-emerald-900 flex justify-between text-xs font-black uppercase text-emerald-800">
            <p>Generated by Camp Hiking Planner System</p>
            <p>Document Status: Approved Proposal</p>
          </div>
        </div>
      </div>
    </div>
  );
};
