import React, { useState } from 'react';
import { ExpeditionPlan, EmergencyContact } from '../types';
import {
  ShieldAlert,
  PhoneCall,
  Radio,
  AlertTriangle,
  Flame,
  Plus,
  Trash2,
  Copy,
  Check,
  Activity,
  Trees
} from 'lucide-react';

interface Props {
  plan: ExpeditionPlan;
  onUpdatePlan: (updated: Partial<ExpeditionPlan>) => void;
}

export const SafetyEmergencySection: React.FC<Props> = ({ plan, onUpdatePlan }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [newContactName, setNewContactName] = useState('');
  const [newContactRole, setNewContactRole] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactNotes, setNewContactNotes] = useState('');
  const [showAddContact, setShowAddContact] = useState(false);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleAddContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContactName.trim() || !newContactPhone.trim()) return;

    const newContact: EmergencyContact = {
      id: `ec-${Date.now()}`,
      name: newContactName.trim(),
      role: newContactRole.trim() || 'Emergency Contact',
      phone: newContactPhone.trim(),
      notes: newContactNotes.trim()
    };

    onUpdatePlan({ emergencyContacts: [...plan.emergencyContacts, newContact] });
    setNewContactName('');
    setNewContactPhone('');
    setNewContactRole('');
    setNewContactNotes('');
    setShowAddContact(false);
  };

  const handleDeleteContact = (id: string) => {
    const updated = plan.emergencyContacts.filter((c) => c.id !== id);
    onUpdatePlan({ emergencyContacts: updated });
  };

  return (
    <div className="space-y-6">
      {/* Section Header */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="p-1.5 bg-rose-500 rounded-lg text-white border-2 border-emerald-900">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <h2 className="text-xl font-black text-emerald-900 uppercase tracking-tight">6. Safety & Emergency Protocols</h2>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-6">
          Safety depends on foresight, redundancy, and defined procedures. Carry satellite communicators in remote areas and establish explicit decision triggers.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Communication Plan */}
          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-4">
            <div className="flex items-center space-x-2 text-emerald-900 border-b-2 border-emerald-200 pb-2">
              <Radio className="w-4 h-4 text-orange-600" />
              <h3 className="text-sm font-black uppercase text-emerald-900 tracking-wide">Communication & Check-Ins</h3>
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Check-In Person (Home Contact)</label>
              <input
                type="text"
                value={plan.checkInPersonName}
                onChange={(e) => onUpdatePlan({ checkInPersonName: e.target.value })}
                className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Contact Phone</label>
              <input
                type="text"
                value={plan.checkInPersonPhone}
                onChange={(e) => onUpdatePlan({ checkInPersonPhone: e.target.value })}
                className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Satellite Communicator / PLB Device ID</label>
              <input
                type="text"
                value={plan.satelliteDevice}
                onChange={(e) => onUpdatePlan({ satelliteDevice: e.target.value })}
                className="w-full bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          {/* Wildlife & Bear Safety */}
          <div className="bg-emerald-50 p-5 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] space-y-4">
            <div className="flex items-center space-x-2 text-emerald-900 border-b-2 border-emerald-200 pb-2">
              <Trees className="w-4 h-4 text-orange-600" />
              <h3 className="text-sm font-black uppercase text-emerald-900 tracking-wide">Wildlife & Food Storage Protocol</h3>
            </div>

            <div>
              <label className="text-xs font-black text-emerald-900 uppercase block mb-1">Bear Vault & Food Storage Strategy</label>
              <textarea
                rows={4}
                value={plan.wildlifeProtocol}
                onChange={(e) => onUpdatePlan({ wildlifeProtocol: e.target.value })}
                className="w-full bg-white border-2 border-emerald-900 rounded-xl p-3 text-xs font-bold text-emerald-950 leading-relaxed focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div className="text-[11px] bg-amber-100 border-2 border-emerald-900 p-2.5 rounded-xl font-bold text-emerald-950">
              <strong className="uppercase font-black text-orange-600">Rule of Thumb:</strong> Hang food 10–12 ft high, 6 ft from tree trunk, and 200 ft downwind from sleeping tents. Never cook or keep scented items inside tents.
            </div>
          </div>
        </div>
      </div>

      {/* Decision-Making Framework */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center space-x-2 border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="p-1.5 bg-amber-500 rounded-lg text-white border-2 border-emerald-900">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Decision-Making Framework & Retreat Triggers</h3>
        </div>

        <p className="text-xs font-bold text-emerald-700 uppercase tracking-wide mb-3">
          Pre-defined triggers for executing backup routes or retreating to lower elevation:
        </p>

        <textarea
          rows={3}
          value={plan.decisionTrigger}
          onChange={(e) => onUpdatePlan({ decisionTrigger: e.target.value })}
          className="w-full bg-emerald-50 border-2 border-emerald-900 rounded-2xl p-4 text-xs font-bold text-emerald-950 leading-relaxed focus:outline-none focus:ring-2 focus:ring-orange-500"
        />
      </div>

      {/* Emergency Contacts List */}
      <div className="bg-white border-4 border-emerald-900 rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(6,78,59,1)]">
        <div className="flex items-center justify-between border-b-2 border-emerald-100 pb-3 mb-4">
          <div className="flex items-center space-x-2">
            <div className="p-1.5 bg-emerald-900 rounded-lg text-white border-2 border-emerald-950">
              <PhoneCall className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-black text-emerald-900 uppercase tracking-tight">Emergency Contacts & Ranger Stations</h3>
          </div>

          <button
            onClick={() => setShowAddContact(!showAddContact)}
            className="flex items-center space-x-1 text-xs font-black uppercase bg-orange-500 hover:bg-orange-400 text-white px-3.5 py-2 rounded-xl border-2 border-emerald-950 shadow-[2px_2px_0px_0px_rgba(6,78,59,1)] transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Contact</span>
          </button>
        </div>

        {showAddContact && (
          <form onSubmit={handleAddContact} className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 mb-4 space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Contact Name / Station"
                value={newContactName}
                onChange={(e) => setNewContactName(e.target.value)}
                className="bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <input
                type="text"
                placeholder="Role / Title"
                value={newContactRole}
                onChange={(e) => setNewContactRole(e.target.value)}
                className="bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Phone / Radio Freq"
                value={newContactPhone}
                onChange={(e) => setNewContactPhone(e.target.value)}
                className="bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <input
                type="text"
                placeholder="Notes / Hours"
                value={newContactNotes}
                onChange={(e) => setNewContactNotes(e.target.value)}
                className="bg-white border-2 border-emerald-900 rounded-xl px-3 py-1.5 text-xs font-bold text-emerald-950 focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
            <div className="flex justify-end space-x-2">
              <button
                type="button"
                onClick={() => setShowAddContact(false)}
                className="px-3 py-1 bg-emerald-100 text-emerald-950 border-2 border-emerald-900 rounded-xl text-xs font-black uppercase"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 bg-orange-500 text-white border-2 border-emerald-950 rounded-xl text-xs font-black uppercase shadow-[2px_2px_0px_0px_rgba(6,78,59,1)]"
              >
                Save Contact
              </button>
            </div>
          </form>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {plan.emergencyContacts.map((contact) => (
            <div
              key={contact.id}
              className="bg-emerald-50 p-4 rounded-2xl border-2 border-emerald-900 shadow-[3px_3px_0px_0px_rgba(6,78,59,1)] flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <h4 className="text-sm font-black text-emerald-950 uppercase">{contact.name}</h4>
                  <button
                    onClick={() => handleDeleteContact(contact.id)}
                    className="text-emerald-800 hover:text-rose-600 text-xs font-black"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[11px] text-orange-600 font-black uppercase mb-2">{contact.role}</p>
                <div className="bg-white px-3 py-1.5 rounded-xl border-2 border-emerald-900 flex items-center justify-between text-xs font-mono font-bold text-emerald-950 mb-2">
                  <span>{contact.phone}</span>
                  <button
                    onClick={() => handleCopy(contact.phone, contact.id)}
                    className="text-emerald-900 hover:text-orange-500 transition"
                    title="Copy Phone Number"
                  >
                    {copiedId === contact.id ? (
                      <Check className="w-3.5 h-3.5 text-orange-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
              <p className="text-[11px] text-emerald-800 font-bold italic">{contact.notes}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
