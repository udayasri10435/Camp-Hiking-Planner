export interface ObjectiveElement {
  id: string;
  element: string;
  details: string;
}

export interface ScheduleItem {
  id: string;
  timeOfDay: string;
  activity: string;
  details: string;
  location?: string;
  completed?: boolean;
}

export interface ItineraryDay {
  id: string;
  dayNumber: number;
  title: string;
  subtitle: string;
  scheduleItems: ScheduleItem[];
}

export interface GearItem {
  id: string;
  name: string;
  quantity: number;
  weightLbs: number;
  assignedTo: string;
  packed: boolean;
  isEssential: boolean;
  category: string;
  type: 'group' | 'personal';
}

export interface BudgetItem {
  id: string;
  category: string;
  estimatedCost: number;
  actualCost: number;
  notes: string;
}

export interface LntRule {
  id: string;
  number: number;
  title: string;
  description: string;
  checked: boolean;
  actionItem: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  role: string;
  phone: string;
  notes: string;
}

export interface MealPlanDay {
  id: string;
  dayNumber: number;
  breakfast: string;
  lunch: string;
  dinner: string;
  snacks: string;
}

export interface ExpeditionPlan {
  id: string;
  userId?: string;
  userEmail?: string;
  userName?: string;
  title: string;
  preparedFor: string;
  preparedBy: string;
  date: string;
  tripDuration: string;
  locationName: string;
  executiveSummary: string;
  
  // Section 2: Objectives
  primaryObjective: string;
  groupSize: string;
  groupProfile: string;
  tripType: string;
  keyThemes: string[];
  
  // Section 3: Location Strategy
  terrainVariety: string;
  waterAccess: string;
  permitRequirements: string;
  seasonalWeather: string;
  permitsSecured: boolean;
  permitDocLink: string;
  
  // Section 4: Itinerary
  itinerary: ItineraryDay[];
  
  // Section 5: Gear
  gearItems: GearItem[];
  
  // Section 6: Safety
  checkInPersonName: string;
  checkInPersonPhone: string;
  satelliteDevice: string;
  wildlifeProtocol: string;
  decisionTrigger: string;
  emergencyContacts: EmergencyContact[];
  
  // Section 7: Nutrition & Water
  dailyCaloriesTarget: number;
  waterCapacityQuarts: number;
  waterTreatmentMethod: string;
  mealPlan: MealPlanDay[];
  
  // Section 8: Budget
  budgetItems: BudgetItem[];
  fundraisingNotes: string;
  
  // Section 9: LNT
  lntRules: LntRule[];
  
  // Section 10: Post Trip
  equipmentCheckComplete: boolean;
  siteInspectionDone: boolean;
  debriefNotes: string;
  photoAlbumUrl: string;
  
  updatedAt: number;
}
