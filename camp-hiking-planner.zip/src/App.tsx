import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, saveExpeditionPlan, subscribeToPlan } from './lib/firebase';
import { ExpeditionPlan } from './types';
import { defaultProposal } from './data/defaultProposal';

import { Header } from './components/Header';
import { Navigation, TabId } from './components/Navigation';
import { ExecutiveSummarySection } from './components/ExecutiveSummarySection';
import { LocationTimingSection } from './components/LocationTimingSection';
import { ItinerarySection } from './components/ItinerarySection';
import { GearPackingSection } from './components/GearPackingSection';
import { SafetyEmergencySection } from './components/SafetyEmergencySection';
import { NutritionWaterSection } from './components/NutritionWaterSection';
import { BudgetSection } from './components/BudgetSection';
import { LeaveNoTraceSection } from './components/LeaveNoTraceSection';
import { PostTripSection } from './components/PostTripSection';
import { AiAssistantModal } from './components/AiAssistantModal';
import { ExportPrintModal } from './components/ExportPrintModal';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabId>('summary');
  const [plan, setPlan] = useState<ExpeditionPlan>(() => {
    const saved = localStorage.getItem('camp_hiking_plan_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return defaultProposal;
      }
    }
    return defaultProposal;
  });

  const [isSynced, setIsSynced] = useState(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Firebase Auth Observer
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Sync to Firestore when user or plan changes
  useEffect(() => {
    localStorage.setItem('camp_hiking_plan_v2', JSON.stringify(plan));

    const syncToCloud = async () => {
      if (user) {
        setIsSynced(false);
        const success = await saveExpeditionPlan(plan, user.uid);
        if (success) {
          setIsSynced(true);
        }
      } else {
        setIsSynced(false);
      }
    };

    const timer = setTimeout(syncToCloud, 1000);
    return () => clearTimeout(timer);
  }, [plan, user]);

  // Subscribe to real-time updates from Firestore if logged in
  useEffect(() => {
    if (!user || !plan.id) return;

    const unsubscribe = subscribeToPlan(plan.id, (cloudPlan) => {
      if (cloudPlan && cloudPlan.updatedAt > (plan.updatedAt || 0)) {
        setPlan(cloudPlan);
        setIsSynced(true);
      }
    });

    return () => unsubscribe();
  }, [user, plan.id]);

  const handleUpdatePlan = (updatedFields: Partial<ExpeditionPlan>) => {
    setPlan((prev) => ({
      ...prev,
      ...updatedFields,
      updatedAt: Date.now()
    }));
  };

  const handleResetToDefault = () => {
    if (window.confirm('Reset proposal to the default 10-section proposal template?')) {
      setPlan(defaultProposal);
      localStorage.setItem('camp_hiking_plan_v2', JSON.stringify(defaultProposal));
    }
  };

  // Counts for tab badges
  const packedCount = plan.gearItems.filter((g) => g.packed).length;
  const totalGearCount = plan.gearItems.length;

  const totalScheduleCount = plan.itinerary.reduce((acc, d) => acc + d.scheduleItems.length, 0);
  const completedScheduleCount = plan.itinerary.reduce(
    (acc, d) => acc + d.scheduleItems.filter((i) => i.completed).length,
    0
  );

  const lntCount = plan.lntRules.filter((r) => r.checked).length;

  return (
    <div className="min-h-screen bg-emerald-50 text-emerald-950 font-sans flex flex-col selection:bg-orange-500 selection:text-white">
      {/* Top Header Navigation */}
      <Header
        user={user}
        authLoading={authLoading}
        isSynced={isSynced}
        activePlanTitle={plan.locationName || plan.title}
        onOpenAiModal={() => setIsAiModalOpen(true)}
        onOpenPrintModal={() => setIsPrintModalOpen(true)}
        onResetToDefault={handleResetToDefault}
      />

      {/* 9-Section Navigation Bar */}
      <Navigation
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        packedCount={packedCount}
        totalGearCount={totalGearCount}
        completedScheduleCount={completedScheduleCount}
        totalScheduleCount={totalScheduleCount}
        lntCount={lntCount}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'summary' && (
          <ExecutiveSummarySection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'location' && (
          <LocationTimingSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'itinerary' && (
          <ItinerarySection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'gear' && (
          <GearPackingSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'safety' && (
          <SafetyEmergencySection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'nutrition' && (
          <NutritionWaterSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'budget' && (
          <BudgetSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'lnt' && (
          <LeaveNoTraceSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
        {activeTab === 'posttrip' && (
          <PostTripSection plan={plan} onUpdatePlan={handleUpdatePlan} />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t-4 border-emerald-900 py-6 text-center text-xs text-emerald-900 font-bold shadow-sm">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="uppercase tracking-wide">© 2026 Camp Hiking Planner — Wilderness Planning System</p>
          <p className="text-[11px] text-emerald-700 font-mono uppercase">
            Firebase Auth • Firestore Persistence • Gemini AI Advisor
          </p>
        </div>
      </footer>

      {/* Modals */}
      <AiAssistantModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        plan={plan}
      />

      <ExportPrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        plan={plan}
      />
    </div>
  );
}
